# Low Poly Desert Oasis Pack (Free)
by reodesuxz

27 low poly desert oasis models: adobe houses, palms, cacti, tents, market stalls, camel and props.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- Oasis_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 2844 triangles for all 27 models (24-220 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| adobe_house | Buildings | 76 | 340 x 360 x 300 |
| domed_mosque | Buildings | 204 | 420 x 340 x 480 |
| market_tower | Buildings | 116 | 230 x 230 x 555 |
| merchant_tent | Buildings | 82 | 339 x 339 x 320 |
| nomad_tent | Buildings | 24 | 360 x 311 x 150 |
| stone_gate | Buildings | 48 | 420 x 90 x 403 |
| palm_tree | Nature | 192 | 355 x 346 x 470 |
| small_palm | Nature | 92 | 199 x 219 x 227 |
| saguaro_cactus | Nature | 184 | 199 x 60 x 350 |
| barrel_cactus | Nature | 100 | 76 x 80 x 84 |
| prickly_pear | Nature | 100 | 105 x 13 x 123 |
| dune_rock | Nature | 40 | 241 x 147 x 132 |
| sandstone_arch | Nature | 36 | 380 x 120 x 365 |
| dry_bush | Nature | 56 | 70 x 89 x 65 |
| oasis_pond | Nature | 208 | 391 x 360 x 46 |
| reed_clump | Nature | 112 | 43 x 44 x 140 |
| stone_well | Props | 112 | 160 x 160 x 235 |
| clay_jar | Props | 116 | 80 x 76 x 95 |
| amphora | Props | 220 | 69 x 50 x 110 |
| treasure_chest | Props | 124 | 102 x 99 x 81 |
| camel | Props | 152 | 240 x 80 x 265 |
| woven_rug | Props | 36 | 200 x 120 x 6 |
| market_stall | Props | 156 | 220 x 120 x 233 |
| hookah | Props | 148 | 89 x 69 x 114 |
| animal_skull | Props | 40 | 69 x 63 x 61 |
| palm_lantern_post | Props | 34 | 35 x 35 x 285 |
| oasis_sign | Props | 36 | 140 x 16 x 150 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
