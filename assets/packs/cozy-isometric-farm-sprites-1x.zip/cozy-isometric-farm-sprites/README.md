# Cozy Isometric Farm Sprites

24 pastel farm models as transparent PNG sprites for isometric farming games and cozy sims: a barn, a stable, a chicken coop, a grain bin, a windpump, field tiles, five crops in four growth stages each, hay, a wheelbarrow, troughs, a fence and a gate, and farm tools. No animals, no figures, no text.

39 sprite sets, each in 4 isometric directions (SE, SW, NE, NW) and a top-down view.
195 sprites per size, two sizes, CC0. Created by grab3d.

Rendered from the matching 3D models on https://grab3d.com, so you can mix 2D and 3D versions of the same asset.
Part of the Cozy Isometric series. Furniture, Nature, Village and Farm share one scale and one floor grid, so they fit together in the same map.

## Projection

True 2:1 isometric pixel projection (dimetric), as used in most isometric games:

* orthographic camera, 30° elevation, 45° azimuth
* floor lines run at exactly 1 pixel up per 2 pixels across
* the model axes are parallel to the floor grid, so the edges of every asset sit on the grid lines

| View | Folder | Directions | Camera |
|---|---|---|---|
| Isometric | `iso` | SE, SW, NE, NW | orthographic, true 2:1 isometric |
| Top-down | `top` | S (front points down) | orthographic, straight down |

The direction names say where the front of the asset faces on screen.
SE and SW face the viewer (front visible), NE and NW face away (back visible).

## Sizes and scale

All assets share one real world scale, so a tulip is tiny next to an oak, just like in real life.
This is the same scale as the Cozy Isometric Furniture Sprites.

| Size | Floor tile (1 m × 1 m) | 1 m height | Top-down |
|---|---|---|---|
| `1x` | 64 × 32 px diamond | 39.2 px | 1 m = 64 px |
| `2x` | 128 × 64 px diamond | 78.4 px | 1 m = 128 px |

### Frame sizes

Small props use the standard square frame. Tall trees and buildings need a bigger square frame so that nothing is cut off.
The frame size of every asset is listed in the table below, in `sourceSize` of every JSON frame and in `meta.grab3d.cellSizes` of the atlas.

| Frame class | 2x frame | 1x frame | Pivot 2x (x, y) | Pivot 1x (x, y) | Assets |
|---|---|---|---|---|---|
| S | 512 × 512 px | 256 × 256 px | 256, 352 | 128, 176 | 34 |
| M | 1024 × 1024 px | 512 × 512 px | 512, 704 | 256, 352 | 2 |
| L | 1536 × 1536 px | 768 × 768 px | 768, 1056 | 384, 528 | 2 |
| XL | 2048 × 2048 px | 1024 × 1024 px | 1024, 1408 | 512, 704 | 1 |

## Pivot (anchor)

The pivot is the centre of the footprint on the floor (middle of the base, at floor height).
It sits at the same relative spot in every frame of every size, measured from the top left:

* isometric: x 0.5, y 0.6875
* top-down: x 0.5, y 0.5

Place a sprite by putting its pivot on the centre of the floor area the asset covers.
For a 1 × 1 asset that is the tile centre. For an asset that covers an even number of tiles in one direction, the centre lies on the edge between two tiles.
Switching directions never makes an asset jump.

Lighting is the same for every sprite (soft key light from the upper left of the screen). There is no ground shadow, so the sprites fit on any floor and any time of day.

## Engine notes

**Godot 4:** use a `Sprite2D` with `centered = false` and `offset = Vector2(-frame / 2, -frame × 0.6875)`, for example `Vector2(-256, -352)` for a 512 px frame or `Vector2(-512, -704)` for a 1024 px frame. The node position is then the floor point. Set the TileMap tile shape to Isometric with tile size 128 × 64 (2x) or 64 × 32 (1x). Turn on Y sort for correct overlap.

**Unity:** import the PNGs as Sprite (2D and UI) with Pixels Per Unit 128 for 2x or 64 for 1x. One floor tile is then 1 × 0.5 units, which matches an Isometric Tilemap with cell size (1, 0.5, 1). Set the pivot to Custom x 0.5, y 0.3125 (Unity measures from the bottom), this works for every frame size. Use Transparency Sort Mode Custom Axis (0, 1, 0) for correct overlap.

**Phaser, PixiJS and TexturePacker importers:** load the `atlas/atlas_2x*.json` or `atlas/atlas_1x*.json` files. Frames are trimmed, the `pivot` field and `spriteSourceSize` restore the floor point.

**Large assets:** buildings and big trees cover several tiles. For correct overlap with Y sort, sort by the pivot, or split the footprint into tiles in your engine. The footprint of every asset is in the JSON files.

## Notes

* Each crop (wheat, corn, carrot, pumpkin, tomato) comes as four separate sprite sets, stage 1 (seedling) to stage 4 (ready to harvest). Place them on the field tiles, a 2 × 2 m field tile holds four plants.
* The field tiles are 2 × 2 m and tile seamlessly along the grid.
* The field tiles are about 15 cm high. When you put a crop on a field tile, lift the crop sprite by about 12 cm (9 px in 2x, 5 px in 1x).
* The chicken coop sprite is shown without the hens of the 3D model, so you can add your own animals.

## Files

```
png/1x/iso/<asset>_iso_<SE|SW|NE|NW>.png   single sprites, 1x
png/1x/top/<asset>_top_S.png
png/2x/...                                  same in 2x
sheets/1x/<asset>_iso.png + .json           4 isometric directions (SE, SW, NE, NW) in one row,
sheets/2x/...                               as a 2 × 2 grid when one row would be wider than 8192 px
atlas/atlas_1x.png + .json
atlas/atlas_2x_1.png, atlas_2x_2.png, atlas_2x_3.png + .json
                                            all sprites packed and trimmed
vorschau.png                                overview on light and dark background (each row in its own scale)
```

The JSON files use the TexturePacker "JSON Hash" format with `frames`, `animations` and a `meta.grab3d` block
(tile size, pixels per metre, pivot, camera and the footprint of every asset in metres and tiles).
Transparent edge pixels carry the neighbouring colour, which avoids dark fringes with bilinear filtering.

## Farm buildings

| Name | Slug | Width | Depth | Height | Tiles | Frame 2x |
|---|---|---|---|---|---|---|
| Barn | `barn` | 9.79 m | 14.75 m | 11.00 m | 10 x 15 | 2048 px |
| Horse Stable | `horse-stable` | 11.61 m | 6.33 m | 7.99 m | 12 x 7 | 1536 px |
| Chicken Coop | `chicken-coop` | 3.62 m | 1.51 m | 2.00 m | 4 x 2 | 512 px |
| Grain Bin | `grain-bin` | 7.29 m | 6.89 m | 7.67 m | 8 x 7 | 1024 px |
| Windpump | `windpump` | 3.77 m | 3.97 m | 9.22 m | 4 x 4 | 1536 px |

## Fields

| Name | Slug | Width | Depth | Height | Tiles | Frame 2x |
|---|---|---|---|---|---|---|
| Tilled Soil Tile | `tilled-soil-tile` | 2.00 m | 2.00 m | 0.16 m | 2 x 2 | 512 px |
| Seeded Soil Tile | `seeded-soil-tile` | 2.00 m | 2.00 m | 0.16 m | 2 x 2 | 512 px |
| Watered Soil Tile | `watered-soil-tile` | 2.00 m | 2.00 m | 0.15 m | 2 x 2 | 512 px |
| Vegetable Garden | `vegetable-garden` | 3.06 m | 2.06 m | 1.62 m | 4 x 3 | 512 px |

## Crops in four growth stages

| Name | Slug | Width | Depth | Height | Tiles | Frame 2x |
|---|---|---|---|---|---|---|
| Wheat, stage 1 | `wheat-stage-1` | 0.17 m | 0.16 m | 0.11 m | 1 x 1 | 512 px |
| Wheat, stage 2 | `wheat-stage-2` | 0.21 m | 0.23 m | 0.23 m | 1 x 1 | 512 px |
| Wheat, stage 3 | `wheat-stage-3` | 0.45 m | 0.41 m | 0.56 m | 1 x 1 | 512 px |
| Wheat, stage 4 | `wheat-stage-4` | 0.66 m | 0.57 m | 1.02 m | 1 x 1 | 512 px |
| Corn, stage 1 | `corn-stage-1` | 0.17 m | 0.20 m | 0.15 m | 1 x 1 | 512 px |
| Corn, stage 2 | `corn-stage-2` | 0.20 m | 0.59 m | 0.39 m | 1 x 1 | 512 px |
| Corn, stage 3 | `corn-stage-3` | 0.30 m | 1.09 m | 1.12 m | 1 x 2 | 512 px |
| Corn, stage 4 | `corn-stage-4` | 0.41 m | 1.20 m | 1.85 m | 1 x 2 | 512 px |
| Carrot, stage 1 | `carrot-stage-1` | 0.17 m | 0.16 m | 0.08 m | 1 x 1 | 512 px |
| Carrot, stage 2 | `carrot-stage-2` | 0.22 m | 0.21 m | 0.14 m | 1 x 1 | 512 px |
| Carrot, stage 3 | `carrot-stage-3` | 0.41 m | 0.48 m | 0.28 m | 1 x 1 | 512 px |
| Carrot, stage 4 | `carrot-stage-4` | 0.75 m | 0.71 m | 0.42 m | 1 x 1 | 512 px |
| Pumpkin, stage 1 | `pumpkin-stage-1` | 0.17 m | 0.16 m | 0.08 m | 1 x 1 | 512 px |
| Pumpkin, stage 2 | `pumpkin-stage-2` | 0.26 m | 0.25 m | 0.19 m | 1 x 1 | 512 px |
| Pumpkin, stage 3 | `pumpkin-stage-3` | 0.74 m | 0.63 m | 0.24 m | 1 x 1 | 512 px |
| Pumpkin, stage 4 | `pumpkin-stage-4` | 0.97 m | 0.77 m | 0.29 m | 1 x 1 | 512 px |
| Tomato, stage 1 | `tomato-stage-1` | 0.17 m | 0.16 m | 0.10 m | 1 x 1 | 512 px |
| Tomato, stage 2 | `tomato-stage-2` | 0.27 m | 0.22 m | 0.20 m | 1 x 1 | 512 px |
| Tomato, stage 3 | `tomato-stage-3` | 0.62 m | 0.52 m | 0.68 m | 1 x 1 | 512 px |
| Tomato, stage 4 | `tomato-stage-4` | 0.67 m | 0.81 m | 1.05 m | 1 x 1 | 512 px |

## Hay, troughs, fences and tools

| Name | Slug | Width | Depth | Height | Tiles | Frame 2x |
|---|---|---|---|---|---|---|
| Round Hay Bale | `hay-bale` | 1.66 m | 1.90 m | 1.51 m | 2 x 2 | 512 px |
| Hay Bale Stack | `hay-bale-stack` | 3.57 m | 2.24 m | 1.10 m | 4 x 3 | 512 px |
| Wheelbarrow | `wheelbarrow` | 1.54 m | 0.64 m | 0.67 m | 2 x 1 | 512 px |
| Water Trough | `water-trough` | 2.49 m | 1.02 m | 0.67 m | 3 x 1 | 512 px |
| Feed Trough | `feed-trough` | 2.21 m | 1.07 m | 1.51 m | 3 x 2 | 512 px |
| Wooden Fence | `wooden-fence` | 3.18 m | 0.28 m | 1.25 m | 4 x 1 | 512 px |
| Farm Gate | `farm-gate` | 4.38 m | 0.37 m | 1.55 m | 5 x 1 | 1024 px |
| Pitchfork | `pitchfork` | 1.06 m | 0.96 m | 1.46 m | 2 x 1 | 512 px |
| Watering Can | `watering-can` | 0.54 m | 0.20 m | 0.38 m | 1 x 1 | 512 px |
| Milk Can | `milk-can` | 0.78 m | 0.52 m | 0.80 m | 1 x 1 | 512 px |

Width runs along the front, depth from front to back. Tiles = width × depth in 1 m tiles, rounded up.

## License

CC0 1.0 Universal (public domain). Use the sprites in personal, commercial and open source projects, change them and share them.
No attribution required. A link to https://grab3d.com is appreciated but never needed. See `LICENSE.txt`.

Created by grab3d · https://grab3d.com
