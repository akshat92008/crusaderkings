# Changelog

## v1.2 (2026-11-20)
- 3 demo VFX from the LITE VFX set: `build_puff` (building finished), `coin_pop` (income), `torch_flame` (with an additive glow layer). FREE now has 190 sprites.
- `fx.json` entries now have `blend` (`normal` / `add`) and an optional `glow` layer.
- The demo has a **VFX gallery** button.
- Nothing was removed or changed in the 1.1 art.

## v1.1 (2026-11)
A much bigger FREE pack: enough to build a whole small village level on its own.
- **Ground autotiles:** 84 new transition tiles. Every corner mask (Wang corner set) for grass↔dirt road, grass↔cobblestone, grass↔sand, grass↔plowed field, grass↔water (sandy bank) and sand↔water. Tiled tileset ships with the terrain set, so you can paint terrain with the terrain brush. Tiles now overlap by half a pixel, so no hairline seams.
- **Town hall** (4×3) with 3 build stages.
- **Modular house:** red tile and blue slate roofs added (3 roofs in total).
- **Resources:** every pile now has 3 fill levels (full / medium / small), and a plank stack was added (4 resources × 3 levels).
- **Wheat crop:** 3 growth stages for fields.
- **Props:** hay bale, wheelbarrow, bench, signpost, lantern post, scarecrow (12 props in total).
- **Fences:** complete join set (20 pieces). Gate along both directions, 4 T-junctions, a cross, 4 run ends and a lone post, plus `fence_join` in `contents.json` (all 16 neighbour cases → piece).
- **Nature:** birch, apple tree, flowering bush, fallen log, rocks, grass tufts (12 in total).
- **Icons:** 24 resource icons (was 12).
- **FX:** chimney smoke (loop), construction dust and a "built!" sparkle, as strips and single frames.
- **Demo:** a bigger sample village, painted with the autotile rules, with chimney smoke and dust/sparkle on the build button.
- Same anchor rules as before, and file names from v1.0 are unchanged. The bottom pad under the anchor grew from 44 / 85 px to 65 / 127 px (the town hall's plot reaches further down), so v1.0 images are taller now: read the pad from `contents.json`.
- Pure ground tiles were re-projected with hard, slightly overlapping edges (no hairline seams between tiles).

## v1.0 (2026-11)
First FREE release: 51 sprites.
