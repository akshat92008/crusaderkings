<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground_128" tilewidth="128" tileheight="64" tilecount="90" columns="10">
  <grid orientation="isometric" width="128" height="64"/>
  <image source="../tiles/@128/ground_sheet.png" width="1280" height="576"/>
  <tile id="0"><properties><property name="name" value="grass"/></properties></tile>
  <tile id="1"><properties><property name="name" value="dirt"/></properties></tile>
  <tile id="2"><properties><property name="name" value="cobble"/></properties></tile>
  <tile id="3"><properties><property name="name" value="water"/></properties></tile>
  <tile id="4"><properties><property name="name" value="sand"/></properties></tile>
  <tile id="5"><properties><property name="name" value="field"/></properties></tile>
  <tile id="6"><properties><property name="name" value="at_grass_dirt_n"/></properties></tile>
  <tile id="7"><properties><property name="name" value="at_grass_dirt_e"/></properties></tile>
  <tile id="8"><properties><property name="name" value="at_grass_dirt_ne"/></properties></tile>
  <tile id="9"><properties><property name="name" value="at_grass_dirt_s"/></properties></tile>
  <tile id="10"><properties><property name="name" value="at_grass_dirt_ns"/></properties></tile>
  <tile id="11"><properties><property name="name" value="at_grass_dirt_es"/></properties></tile>
  <tile id="12"><properties><property name="name" value="at_grass_dirt_nes"/></properties></tile>
  <tile id="13"><properties><property name="name" value="at_grass_dirt_w"/></properties></tile>
  <tile id="14"><properties><property name="name" value="at_grass_dirt_nw"/></properties></tile>
  <tile id="15"><properties><property name="name" value="at_grass_dirt_ew"/></properties></tile>
  <tile id="16"><properties><property name="name" value="at_grass_dirt_new"/></properties></tile>
  <tile id="17"><properties><property name="name" value="at_grass_dirt_sw"/></properties></tile>
  <tile id="18"><properties><property name="name" value="at_grass_dirt_nsw"/></properties></tile>
  <tile id="19"><properties><property name="name" value="at_grass_dirt_esw"/></properties></tile>
  <tile id="20"><properties><property name="name" value="at_grass_cobble_n"/></properties></tile>
  <tile id="21"><properties><property name="name" value="at_grass_cobble_e"/></properties></tile>
  <tile id="22"><properties><property name="name" value="at_grass_cobble_ne"/></properties></tile>
  <tile id="23"><properties><property name="name" value="at_grass_cobble_s"/></properties></tile>
  <tile id="24"><properties><property name="name" value="at_grass_cobble_ns"/></properties></tile>
  <tile id="25"><properties><property name="name" value="at_grass_cobble_es"/></properties></tile>
  <tile id="26"><properties><property name="name" value="at_grass_cobble_nes"/></properties></tile>
  <tile id="27"><properties><property name="name" value="at_grass_cobble_w"/></properties></tile>
  <tile id="28"><properties><property name="name" value="at_grass_cobble_nw"/></properties></tile>
  <tile id="29"><properties><property name="name" value="at_grass_cobble_ew"/></properties></tile>
  <tile id="30"><properties><property name="name" value="at_grass_cobble_new"/></properties></tile>
  <tile id="31"><properties><property name="name" value="at_grass_cobble_sw"/></properties></tile>
  <tile id="32"><properties><property name="name" value="at_grass_cobble_nsw"/></properties></tile>
  <tile id="33"><properties><property name="name" value="at_grass_cobble_esw"/></properties></tile>
  <tile id="34"><properties><property name="name" value="at_grass_sand_n"/></properties></tile>
  <tile id="35"><properties><property name="name" value="at_grass_sand_e"/></properties></tile>
  <tile id="36"><properties><property name="name" value="at_grass_sand_ne"/></properties></tile>
  <tile id="37"><properties><property name="name" value="at_grass_sand_s"/></properties></tile>
  <tile id="38"><properties><property name="name" value="at_grass_sand_ns"/></properties></tile>
  <tile id="39"><properties><property name="name" value="at_grass_sand_es"/></properties></tile>
  <tile id="40"><properties><property name="name" value="at_grass_sand_nes"/></properties></tile>
  <tile id="41"><properties><property name="name" value="at_grass_sand_w"/></properties></tile>
  <tile id="42"><properties><property name="name" value="at_grass_sand_nw"/></properties></tile>
  <tile id="43"><properties><property name="name" value="at_grass_sand_ew"/></properties></tile>
  <tile id="44"><properties><property name="name" value="at_grass_sand_new"/></properties></tile>
  <tile id="45"><properties><property name="name" value="at_grass_sand_sw"/></properties></tile>
  <tile id="46"><properties><property name="name" value="at_grass_sand_nsw"/></properties></tile>
  <tile id="47"><properties><property name="name" value="at_grass_sand_esw"/></properties></tile>
  <tile id="48"><properties><property name="name" value="at_grass_field_n"/></properties></tile>
  <tile id="49"><properties><property name="name" value="at_grass_field_e"/></properties></tile>
  <tile id="50"><properties><property name="name" value="at_grass_field_ne"/></properties></tile>
  <tile id="51"><properties><property name="name" value="at_grass_field_s"/></properties></tile>
  <tile id="52"><properties><property name="name" value="at_grass_field_ns"/></properties></tile>
  <tile id="53"><properties><property name="name" value="at_grass_field_es"/></properties></tile>
  <tile id="54"><properties><property name="name" value="at_grass_field_nes"/></properties></tile>
  <tile id="55"><properties><property name="name" value="at_grass_field_w"/></properties></tile>
  <tile id="56"><properties><property name="name" value="at_grass_field_nw"/></properties></tile>
  <tile id="57"><properties><property name="name" value="at_grass_field_ew"/></properties></tile>
  <tile id="58"><properties><property name="name" value="at_grass_field_new"/></properties></tile>
  <tile id="59"><properties><property name="name" value="at_grass_field_sw"/></properties></tile>
  <tile id="60"><properties><property name="name" value="at_grass_field_nsw"/></properties></tile>
  <tile id="61"><properties><property name="name" value="at_grass_field_esw"/></properties></tile>
  <tile id="62"><properties><property name="name" value="at_grass_water_n"/></properties></tile>
  <tile id="63"><properties><property name="name" value="at_grass_water_e"/></properties></tile>
  <tile id="64"><properties><property name="name" value="at_grass_water_ne"/></properties></tile>
  <tile id="65"><properties><property name="name" value="at_grass_water_s"/></properties></tile>
  <tile id="66"><properties><property name="name" value="at_grass_water_ns"/></properties></tile>
  <tile id="67"><properties><property name="name" value="at_grass_water_es"/></properties></tile>
  <tile id="68"><properties><property name="name" value="at_grass_water_nes"/></properties></tile>
  <tile id="69"><properties><property name="name" value="at_grass_water_w"/></properties></tile>
  <tile id="70"><properties><property name="name" value="at_grass_water_nw"/></properties></tile>
  <tile id="71"><properties><property name="name" value="at_grass_water_ew"/></properties></tile>
  <tile id="72"><properties><property name="name" value="at_grass_water_new"/></properties></tile>
  <tile id="73"><properties><property name="name" value="at_grass_water_sw"/></properties></tile>
  <tile id="74"><properties><property name="name" value="at_grass_water_nsw"/></properties></tile>
  <tile id="75"><properties><property name="name" value="at_grass_water_esw"/></properties></tile>
  <tile id="76"><properties><property name="name" value="at_sand_water_n"/></properties></tile>
  <tile id="77"><properties><property name="name" value="at_sand_water_e"/></properties></tile>
  <tile id="78"><properties><property name="name" value="at_sand_water_ne"/></properties></tile>
  <tile id="79"><properties><property name="name" value="at_sand_water_s"/></properties></tile>
  <tile id="80"><properties><property name="name" value="at_sand_water_ns"/></properties></tile>
  <tile id="81"><properties><property name="name" value="at_sand_water_es"/></properties></tile>
  <tile id="82"><properties><property name="name" value="at_sand_water_nes"/></properties></tile>
  <tile id="83"><properties><property name="name" value="at_sand_water_w"/></properties></tile>
  <tile id="84"><properties><property name="name" value="at_sand_water_nw"/></properties></tile>
  <tile id="85"><properties><property name="name" value="at_sand_water_ew"/></properties></tile>
  <tile id="86"><properties><property name="name" value="at_sand_water_new"/></properties></tile>
  <tile id="87"><properties><property name="name" value="at_sand_water_sw"/></properties></tile>
  <tile id="88"><properties><property name="name" value="at_sand_water_nsw"/></properties></tile>
  <tile id="89"><properties><property name="name" value="at_sand_water_esw"/></properties></tile>
  <wangsets>
   <wangset name="terrain" type="corner" tile="0">
    <wangcolor name="grass" color="#6fa040" tile="0" probability="1"/>
    <wangcolor name="dirt" color="#a87a4a" tile="1" probability="1"/>
    <wangcolor name="cobble" color="#8c8c8c" tile="2" probability="1"/>
    <wangcolor name="water" color="#3c8fd0" tile="3" probability="1"/>
    <wangcolor name="sand" color="#e6c88c" tile="4" probability="1"/>
    <wangcolor name="field" color="#5a3a22" tile="5" probability="1"/>
    <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
    <wangtile tileid="1" wangid="0,2,0,2,0,2,0,2"/>
    <wangtile tileid="2" wangid="0,3,0,3,0,3,0,3"/>
    <wangtile tileid="3" wangid="0,4,0,4,0,4,0,4"/>
    <wangtile tileid="4" wangid="0,5,0,5,0,5,0,5"/>
    <wangtile tileid="5" wangid="0,6,0,6,0,6,0,6"/>
    <wangtile tileid="6" wangid="0,1,0,1,0,1,0,2"/>
    <wangtile tileid="7" wangid="0,2,0,1,0,1,0,1"/>
    <wangtile tileid="8" wangid="0,2,0,1,0,1,0,2"/>
    <wangtile tileid="9" wangid="0,1,0,2,0,1,0,1"/>
    <wangtile tileid="10" wangid="0,1,0,2,0,1,0,2"/>
    <wangtile tileid="11" wangid="0,2,0,2,0,1,0,1"/>
    <wangtile tileid="12" wangid="0,2,0,2,0,1,0,2"/>
    <wangtile tileid="13" wangid="0,1,0,1,0,2,0,1"/>
    <wangtile tileid="14" wangid="0,1,0,1,0,2,0,2"/>
    <wangtile tileid="15" wangid="0,2,0,1,0,2,0,1"/>
    <wangtile tileid="16" wangid="0,2,0,1,0,2,0,2"/>
    <wangtile tileid="17" wangid="0,1,0,2,0,2,0,1"/>
    <wangtile tileid="18" wangid="0,1,0,2,0,2,0,2"/>
    <wangtile tileid="19" wangid="0,2,0,2,0,2,0,1"/>
    <wangtile tileid="20" wangid="0,1,0,1,0,1,0,3"/>
    <wangtile tileid="21" wangid="0,3,0,1,0,1,0,1"/>
    <wangtile tileid="22" wangid="0,3,0,1,0,1,0,3"/>
    <wangtile tileid="23" wangid="0,1,0,3,0,1,0,1"/>
    <wangtile tileid="24" wangid="0,1,0,3,0,1,0,3"/>
    <wangtile tileid="25" wangid="0,3,0,3,0,1,0,1"/>
    <wangtile tileid="26" wangid="0,3,0,3,0,1,0,3"/>
    <wangtile tileid="27" wangid="0,1,0,1,0,3,0,1"/>
    <wangtile tileid="28" wangid="0,1,0,1,0,3,0,3"/>
    <wangtile tileid="29" wangid="0,3,0,1,0,3,0,1"/>
    <wangtile tileid="30" wangid="0,3,0,1,0,3,0,3"/>
    <wangtile tileid="31" wangid="0,1,0,3,0,3,0,1"/>
    <wangtile tileid="32" wangid="0,1,0,3,0,3,0,3"/>
    <wangtile tileid="33" wangid="0,3,0,3,0,3,0,1"/>
    <wangtile tileid="34" wangid="0,1,0,1,0,1,0,5"/>
    <wangtile tileid="35" wangid="0,5,0,1,0,1,0,1"/>
    <wangtile tileid="36" wangid="0,5,0,1,0,1,0,5"/>
    <wangtile tileid="37" wangid="0,1,0,5,0,1,0,1"/>
    <wangtile tileid="38" wangid="0,1,0,5,0,1,0,5"/>
    <wangtile tileid="39" wangid="0,5,0,5,0,1,0,1"/>
    <wangtile tileid="40" wangid="0,5,0,5,0,1,0,5"/>
    <wangtile tileid="41" wangid="0,1,0,1,0,5,0,1"/>
    <wangtile tileid="42" wangid="0,1,0,1,0,5,0,5"/>
    <wangtile tileid="43" wangid="0,5,0,1,0,5,0,1"/>
    <wangtile tileid="44" wangid="0,5,0,1,0,5,0,5"/>
    <wangtile tileid="45" wangid="0,1,0,5,0,5,0,1"/>
    <wangtile tileid="46" wangid="0,1,0,5,0,5,0,5"/>
    <wangtile tileid="47" wangid="0,5,0,5,0,5,0,1"/>
    <wangtile tileid="48" wangid="0,1,0,1,0,1,0,6"/>
    <wangtile tileid="49" wangid="0,6,0,1,0,1,0,1"/>
    <wangtile tileid="50" wangid="0,6,0,1,0,1,0,6"/>
    <wangtile tileid="51" wangid="0,1,0,6,0,1,0,1"/>
    <wangtile tileid="52" wangid="0,1,0,6,0,1,0,6"/>
    <wangtile tileid="53" wangid="0,6,0,6,0,1,0,1"/>
    <wangtile tileid="54" wangid="0,6,0,6,0,1,0,6"/>
    <wangtile tileid="55" wangid="0,1,0,1,0,6,0,1"/>
    <wangtile tileid="56" wangid="0,1,0,1,0,6,0,6"/>
    <wangtile tileid="57" wangid="0,6,0,1,0,6,0,1"/>
    <wangtile tileid="58" wangid="0,6,0,1,0,6,0,6"/>
    <wangtile tileid="59" wangid="0,1,0,6,0,6,0,1"/>
    <wangtile tileid="60" wangid="0,1,0,6,0,6,0,6"/>
    <wangtile tileid="61" wangid="0,6,0,6,0,6,0,1"/>
    <wangtile tileid="62" wangid="0,1,0,1,0,1,0,4"/>
    <wangtile tileid="63" wangid="0,4,0,1,0,1,0,1"/>
    <wangtile tileid="64" wangid="0,4,0,1,0,1,0,4"/>
    <wangtile tileid="65" wangid="0,1,0,4,0,1,0,1"/>
    <wangtile tileid="66" wangid="0,1,0,4,0,1,0,4"/>
    <wangtile tileid="67" wangid="0,4,0,4,0,1,0,1"/>
    <wangtile tileid="68" wangid="0,4,0,4,0,1,0,4"/>
    <wangtile tileid="69" wangid="0,1,0,1,0,4,0,1"/>
    <wangtile tileid="70" wangid="0,1,0,1,0,4,0,4"/>
    <wangtile tileid="71" wangid="0,4,0,1,0,4,0,1"/>
    <wangtile tileid="72" wangid="0,4,0,1,0,4,0,4"/>
    <wangtile tileid="73" wangid="0,1,0,4,0,4,0,1"/>
    <wangtile tileid="74" wangid="0,1,0,4,0,4,0,4"/>
    <wangtile tileid="75" wangid="0,4,0,4,0,4,0,1"/>
    <wangtile tileid="76" wangid="0,5,0,5,0,5,0,4"/>
    <wangtile tileid="77" wangid="0,4,0,5,0,5,0,5"/>
    <wangtile tileid="78" wangid="0,4,0,5,0,5,0,4"/>
    <wangtile tileid="79" wangid="0,5,0,4,0,5,0,5"/>
    <wangtile tileid="80" wangid="0,5,0,4,0,5,0,4"/>
    <wangtile tileid="81" wangid="0,4,0,4,0,5,0,5"/>
    <wangtile tileid="82" wangid="0,4,0,4,0,5,0,4"/>
    <wangtile tileid="83" wangid="0,5,0,5,0,4,0,5"/>
    <wangtile tileid="84" wangid="0,5,0,5,0,4,0,4"/>
    <wangtile tileid="85" wangid="0,4,0,5,0,4,0,5"/>
    <wangtile tileid="86" wangid="0,4,0,5,0,4,0,4"/>
    <wangtile tileid="87" wangid="0,5,0,4,0,4,0,5"/>
    <wangtile tileid="88" wangid="0,5,0,4,0,4,0,4"/>
    <wangtile tileid="89" wangid="0,4,0,4,0,4,0,5"/>
   </wangset>
  </wangsets>
</tileset>
