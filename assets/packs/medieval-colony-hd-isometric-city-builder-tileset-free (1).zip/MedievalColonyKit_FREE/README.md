# Medieval Colony: Isometric Kit (FREE v1.1)

A cozy medieval village for city-builder and colony games, in clean HD cartoon style on an exact 2:1 isometric grid.
Every piece shares one grid, one light direction (sun from the top-left) and one anchor rule, so they snap together.
The FREE pack alone is enough to build a whole small village level (see `demo/`).

What makes it different:
- **Build stages:** the town hall and the house come as foundation + scaffolding, half-built, and finished.
- **Modular house:** foundation, walls and 3 roofs are separate sprites that stack on one anchor.
- **Resource piles with fill levels:** logs, stone, grain sacks and planks as full, medium and small piles.
- **Autotile ground:** every corner transition between the terrains, ready for Tiled's terrain brush.
- **Joinable fences** for every neighbour case: straights, gates, corners, T-junctions, a cross and run ends.

## What's inside

| Folder | Contents |
|---|---|
| `buildings/` | Timber house 2×2: `house_stage1..3`. Town hall 4×3: `hall_stage1..3`. Modules: `house_foundation`, `house_walls`, `house_roof_thatch`, `house_roof_tile`, `house_roof_slate` |
| `resources/` | `logs_`, `stone_`, `sacks_`, `planks_` × `full` / `medium` / `small` (`fill_level` 3 / 2 / 1 in the JSON) |
| `crops/` | `wheat_crop_1..3` (sprouts, green, ripe; `growth_stage` in the JSON). Put them on `field` tiles |
| `props/` | Well, market stall (2×1), crates, barrels, handcart, wheat sheaves, hay bale, wheelbarrow, bench, signpost, lantern post, scarecrow |
| `fences/` | `fence_x`, `fence_y`, `gate_x`, `gate_y`, corners `fence_corner_es/ws/en/wn`, T-junctions `fence_t_nes/new/nsw/esw`, `fence_cross`, run ends `fence_end_n/e/s/w`, lone post `fence_post_c`, v1.0 end caps `fence_post_x/y` |
| `nature/` | Oak, pine, birch, apple tree, bush, flowering bush, stump, fallen log, boulder, rocks, red flowers, grass tufts |
| `tiles/` | 6 pure tiles (grass, dirt, cobble, water, sand, field) + 84 autotile transitions `at_<base>_<over>_<corners>` + `ground_sheet.png` per size |
| `icons/` | 24 resource icons |
| `fx/` | `smoke` (loop), `dust`, `sparkle` + 3 demo VFX `build_puff`, `coin_pop`, `torch_flame` (with glow): a strip per FX and single frames in `frames/`; fps, frame size, anchor and blend in `fx.json`. LITE has 20 VFX |
| `tiled/` | Tiled tilesets (`ground_*.tsx` with a terrain set, `objects_*.tsx`) and a sample map `sample_village_*.tmx` for each size |
| `demo/` | `index.html`: the sample village in plain JavaScript. Opens straight from disk. Try **Build ▶**, **Grow / fill ▶** and **Show house modules apart** |

Sizes:
- Sprites, tiles and FX come as `@128` (tile 128×64) and `@256` (tile 256×128, for HD or zoomed games).
- Icons come as `@64` and `@128`.

All PNGs have true transparency. The soft contact shadows are in the alpha. `contents.json` lists everything and the sprite count.

## Grid and anchors

- **Grid:** a tile is a 2:1 diamond, TW×TH = 128×64 (or 256×128). The screen position of grid point (gx, gy) is `x = (gx − gy)·TW/2`, `y = (gx + gy)·TH/2`.
- **Tiles:** put the image's **top-left** at `(x − TW/2, y)` of the cell's north corner. In other words, the bottom-centre goes on the cell's south corner, as Tiled does for isometric maps. Ground tiles are hard-edged and half a pixel bigger than the diamond, so neighbours overlap and no seams show.
- **Objects** (`buildings`, `resources`, `crops`, `props`, `fences`, `nature`):
  - Each `<folder>.json` gives `anchor`: the pixel of the footprint's **south corner** inside the image.
  - Put that pixel on grid point `(gx + w, gy + h)`, where `footprint` = [w, h] in tiles.
  - Every object image is padded so the anchor is at the **horizontal centre** and a fixed distance above the bottom edge: 65 px @128, 127 px @256 (`contents.json` → `pad_below_anchor`). So in most engines you can use one origin per size, `(0.5, 1 − pad/height)`. This pad grew in v1.1 (the town hall's plot reaches further down); always read it from the JSON.
- **Build stages and modules:** all `house_stage*` sprites and the house modules share the same footprint and anchor, so you can swap them in place. To build the house from modules, draw foundation, then walls, then one roof at the same anchor. The town hall stages share their own 4×3 footprint.
- **Depth sorting:** draw objects in order of `gx + gy + (w + h)/2` (the footprint centre); for modules at the same spot draw foundation, walls, roof. This works for village layouts like the sample. Very large or L-shaped footprints need a topological sort.

## Autotile ground (Wang corners)

- Terrain is stored per **grid point**. A cell takes its tile from its 4 corners: `n` = (x, y), `e` = (x+1, y), `s` = (x+1, y+1), `w` = (x, y+1).
- All 4 corners the same → the pure tile (`grass.png`, …).
- Two terrains → `at_<base>_<over>_<corners that are over>.png`, for the pairs grass/dirt, grass/cobble, grass/sand, grass/field, grass/water, sand/water. Example: dirt at the n and e corners of a grass cell → `at_grass_dirt_ne.png`.
- Three terrains in one cell have no tile: keep one row of grass (or sand next to water) between different terrains. The demo's `cellTile()` is a 10-line reference.
- `tiles.json` gives the corner terrains of every tile. In Tiled, use the **terrain** set in `ground_*.tsx` with the terrain brush.

## Fences

- A fence runs through the middle of its tiles. Each arm reaches the midpoint of a tile edge: `n` = toward grid y−1, `e` = x+1, `s` = y+1, `w` = x−1.
- Look at which of the 4 neighbouring cells also have a fence, and take the piece from `contents.json` → `fence_join.pieces` (16 cases). `gate_x` / `gate_y` replace `fence_x` / `fence_y`.
- Each piece draws only its **own start post**; the next piece's post covers the rail end. Draw fences in depth order like everything else.

## FX

- `fx.json`: `frames`, `frame_size`, `fps`, `loop`, `anchor` (pixel in the frame that goes on the target point) and `blend`: `normal` (alpha blending) or `add` (additive: Godot `CanvasItemMaterial` blend mode *Add*, Phaser `ADD`, canvas `lighter`). Some effects also have a `glow` layer (own strip + frames, always additive): draw it with the same frame and anchor, under or over the effect.
- **Smoke:** target = the chimney. `buildings.json` gives `fx_points.smoke` (offset from the sprite's anchor) on `house_stage3` and `house_roof_thatch`.
- **Dust / sparkle:** target = the footprint centre on the ground, e.g. dust while building, sparkle when a stage finishes.
- **Demo VFX (1.2):** `build_puff` when a building is finished (footprint centre), `coin_pop` over a building that pays income, `torch_flame` on a lantern, brazier or wall torch (anchor = flame base). The demo's **VFX gallery** button plays them all.
- The LITE file has the full VFX set (20 effects): construction, demolish, select ring, build marker, coins, harvest, hearts, level-up, sickness, building fire, steam, water splash, anvil sparks, torch, lantern glow, fireflies, rain, rain ripples, birds.

## Tiled

- Open `tiled/sample_village_128.tmx` (or `_256`). The object tileset uses `objectalignment="bottom"` plus a tile offset equal to the pad, so a tile object placed on a grid point stands on that point.
- Objects are kept in draw order (`draworder="index"`). Re-order them if you move things around.
- The `.tsx/.tmx` files were written by our build script for Tiled 1.10. **We have not opened them in Tiled itself.** If something is off, the JSON is the reference.

## License

See `LICENSE.txt`. Free for personal and commercial games. Do not resell or redistribute the assets themselves.

## AI disclosure

The art was made with the help of generative AI image tools: ChatGPT painted over our own grey-box models, and Gemini painted the ground textures. The grid, grey-boxes, cut-out, fence fitting, autotile transitions, tile projection, FX, metadata, Tiled files and demo were made by dotPLAYS in code and by hand.
