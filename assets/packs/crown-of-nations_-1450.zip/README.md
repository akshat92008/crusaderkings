# Crown of Nations — 1450

**A playable, zero-dependency browser grand-strategy prototype** with a worldwide 1450-themed campaign, customizable royal policies, territorial conquest, recruitment, construction, diplomacy, economic simulation, AI rivals, and controllable real-time 3D tactical battles.

![World map preview](docs/world-preview.png)

> **State of development: playable development build.** The default atlas has 56 starting realms and 576 approximate gameplay districts. Historical-reference alignment is incomplete; the game is fictional alternate history, not an exact 1450 reconstruction. See [release acceptance](docs/RELEASE_ACCEPTANCE.md) and [known limitations](docs/KNOWN_LIMITATIONS.md). Earlier milestone descriptions below describe legacy versions.

## Play locally — no dependency installation

1. Download/extract the project ZIP (or clone the Git repository). On a Mac, you can double-click `START_GAME_MAC.command` (if Python 3 is installed). Windows users can launch `START_GAME_WINDOWS.bat`.
2. Open a terminal in the project directory.
3. Run `python3 -m http.server 8080` (Mac/Linux), or `py -m http.server 8080` on Windows.
4. Visit **http://localhost:8080** in Chrome, Edge, Firefox, or Safari.
5. Choose a historical polity and click **Begin Your Reign**.

The game runs locally after the files load; it does not need a game server, npm packages, cloud accounts, or a paid API. Google Fonts may load if online; system fonts are the fallback. Local saves are tied to the browser and origin (`localhost:8080`).

## What works today

- 576 approximate gameplay districts across six continents; 56 starting playable realms. Pan/zoom/inspect, political and historical layers, mobile touch gestures.
- Map-first interface with five on-demand management workspaces, searchable realm selection and portable save import/export.
- Monthly calendar progression, treasury, revenue, upkeep, food, unrest, stability, legitimacy, prestige, and population growth.
- Three classes of **royal decrees**: taxation, recruitment laws, and tolerance.
- Four **province buildings**: farms, markets, barracks, and forts; each upgrades three times.
- Recruitment of infantry, archers, and cavalry, with budget and unrest consequences.
- Adjacent land movement, manual battles against rival provinces, capture, casualties, and territory transfer to campaign.
- Real-time battlefield with 12 formations, soldier formations (infantry, archers, cavalry), rally banners, ranged attacks, morale, routs, basic enemy behavior, movement orders, and win/lose outcomes.
- Native instanced **WebGL2 renderer**, with an alternate Canvas 2D renderer projecting 3D cuboids when WebGL2 is unavailable. Does not rely on external 3D engines or CDNs.
- Rival AI invests, recruits, and fights limited autonomous border conflicts. Not full diplomatic/strategic AI.
- Diplomatic gifts, improved relations, alliance proposals, insults, an event chronicle, manual and automatic time progression.
- Browser localStorage save/continue, automatic monthly saves, portable JSON export/import; deterministic campaign simulation core.

## Controls

| Campaign | Battlefield |
| --- | --- |
| Drag map to pan; scroll to zoom | Left-click regiment or press `1–6` |
| Click a province to inspect | Right-click terrain to move selected regiment |
| In an owned province, choose **Issue March / Attack Order** then click an adjacent destination | `WASD` pan, `Q/E` rotate, mouse wheel zoom |
| **Advance Month** steps the campaign; `▶` auto-progresses | `Space` pause, Retreat button concedes |
| Save button stores the campaign locally | After battle, **Return to Campaign** applies casualties and territorial result |

## Project structure

```text
index.html                     Main application shell and accessible controls
styles.css                     Dark parchment-themed strategy UI
src/main.js                    Screens, event handling, game orchestration
src/map.js                     Interactive Canvas2D cartographic renderer
src/simulation.js              Deterministic economic, political & war simulation
src/battle.js                  WebGL2 / perspective 2D tactical renderer and AI
data/world.json                Generated provinces, connections, 44 factions
assets/naturalearth/           Bundled Natural Earth public-domain shapefile
assets/favicon.svg             Original icon
scripts/build_world.py         Rebuild province layout from bundled data
scripts/render_smoke_test.py   Optional Linux Playwright UI integration test
tests/simulation.test.mjs      7 Node.js simulation regression tests
docs/GAME_BLUEPRINT.md         Architecture and extended design specification
docs/ASSET_MANIFEST.md         Verified CC0/public-domain assets and import priorities
docs/IMPLEMENTATION_PLAN.md    Concrete next implementation milestones
docs/KNOWN_LIMITATIONS.md      What is incomplete and what was actually tested
```

## Verification

```bash
node --test tests/*.test.mjs
node --check src/main.js
node --check src/simulation.js
node --check src/map.js
node --check src/battle.js
```

The Python-based visual test in `scripts/render_smoke_test.py` is a development-only harness requiring Python Playwright and a local Chromium executable; its hardcoded Linux path must be adapted on Mac/Windows. The actual game has **no Python or npm dependencies at runtime**, except a tiny static file server to serve ES modules and JSON. Previews included in `docs/` were taken from this integration harness.

## Sources and licenses

- **Natural Earth** geography is [public domain](https://www.naturalearthdata.com/about/terms-of-use/); included shapefile is used for coastlines/landmass, not modern national borders in gameplay. Generated political test cells are original procedural geometry.
- Game implementation (excluding third-party assets) is released under the MIT license (see `LICENSE`).
- **Other researched CC0 asset packs are listed but NOT shipped**. No unverified art, sound, fonts, or historical border data have been silently copied into the repository. See [Asset Manifest](docs/ASSET_MANIFEST.md).

## Publishing to a *new* GitHub repository

The package can be used as a local Git repository. If you're adding the downloaded ZIP to an empty repository created on GitHub, from its extracted directory run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/crown-of-nations.git
git push -u origin main
```

Create an empty repository in GitHub first, **without** initializing README/license, and replace `YOUR_USERNAME` with your own account. Creating a remote repository requires repository-creation permissions. The game is not hosted or automatically deployed just because the files exist locally.

## Credits

Design and implementation: AI-assisted prototype built for the requester. Map base data: Natural Earth (public domain). No assets from Crusader Kings, Europa Universalis or Total War are distributed with this project; their names describe genre references only.

## Milestone 01 — Real GLB battlefield scenery

The native WebGL2 battle can load CC0 Kenney castle GLB models and existing historical Indian source models. Infantry formations now use additional low-poly geometry types. Existing campaign, diplomacy, economy and battle-result logic are preserved. See [milestone verification](docs/MILESTONE_01_BATTLE_3D.md).

The downloadable Milestone 01 package includes a small CC0 Kenney subset. When using this GitHub branch directly, import your copy of the official [Kenney Castle Kit](https://kenney.nl/assets/castle-kit) using:

```bash
python3 scripts/import_kenney_castle.py /path/to/kenney_castle-kit.zip
```

The source branch's stone wall GLB is a fallback when the local Kenney wall is absent. The world map and battle graphics are still work in progress; native WebGL2 visual quality has not yet been GPU-tested in this environment.

## Milestone 02: Interactive 3D World Atlas

This development branch includes a WebGL2 3D relief campaign renderer, political and terrain modes, an optional Cliopatria historical-reference overlay, and graceful 2D fallback. The 3D height field is a **stylized approximation, not a surveyed elevation model**, while the original 299 playable provinces remain experimental/synthetic.

Run the static build using `python3 -m http.server 8080`. See [the full milestone report](docs/MILESTONE_02_CAMPAIGN_3D.md) for the source-asset generation commands and limitations. The ready-to-run Milestone 02 ZIP supplied in chat already contains its generated imagery and historical GeoJSON; the GitHub branch does not yet bundle those binaries/data.


## Milestone 03: Animated 3D armies (development preview)

WebGL2 battles now use original CC0 KayKit **Knight** and **Rogue Hooded** character GLBs, animated at runtime, including mounted Knight riders on procedural horses. The game continues to work without WebGL2 by rendering the previous geometric battlefield.

The two locally bundled rigged characters and the self-hosted Three.js scene come from a reproducible script:

```bash
npm ci
npm run build:battle
python3 -m http.server 8080
```

No internet connection is needed to play the packaged release. See [Milestone 03 report](docs/MILESTONE_03_ANIMATED_ARMIES.md) and the [actual browser-rendered screenshot](docs/battle-real-kaykit-3d.png). **This is not yet a complete or visually polished grand-strategy game.**


## Milestone 04: Medieval Battlefields (v0.5 development playtest)

The browser battle now renders an original medieval fortified settlement, village, castle gate, camps, catapults, roads, trees, barrels and textures. Animated KayKit infantry, archers and mounted soldiers remain playable. Environment geometry is batched for efficient WebGL2 rendering. The walls and catapults are visual scenery and are **not yet destructible**.

**To inspect it immediately:** begin a reign, then select **⚔ BATTLE SHOWCASE** from the map controls. This starts a practice encounter without changing your troops, treasury, provinces, or saves.

See the [milestone details](docs/MILESTONE_04_MEDIEVAL_BATTLEFIELD.md) and [actual Chromium screenshot](docs/battle-medieval-fortress-3d.png). The v0.5 playable ZIP includes the local KayKit GLBs and browser-renderer bundle; the 730 MB raw architecture library remains outside the playtest.


## Milestone 05 — Royal Courts, Trade, Events and AI

The campaign now includes generated (fictional) royal dynasties and succession for all 44 factions, five playable court decisions, merchant trade treaties, dynastic marriage diplomacy, **23 interactive narrative events**, smarter rule-based kingdom AI and attacks with warning periods, Peaceful/Normal/Hard difficulty, six campaign objectives, and a year-1500 legacy assessment.

Use the new **ROYAL COURT**, **TRADE**, and **LEGACY** tabs to play these systems. Royal events appear every nine months of game time if there is no unresolved event. Old saves are upgraded automatically. All AI behavior is local and deterministic—not based on an external paid service.

See [Milestone 05 details and limitations](docs/MILESTONE_05_KINGDOM_AI.md).

This remains an early-access prototype: historically correct world borders, full dynasty/vassal depth, naval mechanics, complex siege gameplay, cultural unit diversity and final optimization are still missing.


## Milestone 06 — Cultural warfare and enemy attacks

The v0.7 development branch now includes **15 original military doctrines** and **ten tactical formations** with actual differences in army mixes and battle statistics. Animated troops use visible wedge, line, square and flanking deployments.

Rival kingdoms can **initiate border invasions** instead of leaving every war to the human player. They marshal an existing army, cross connected territory, issue a warning and launch a playable defensive battle. Choose a troop formation and a left/center/right deployment lane, then click **Start Assault**. A defending player may also auto-resolve the battle. Defenses, casualties and the resulting province ownership are saved.

This does **not** implement a complete Clash of Clans destructible village system or CK3's full title/claim/dynasty simulation. Read [the technical milestone report](docs/MILESTONE_06_CULTURAL_WARFARE.md).
