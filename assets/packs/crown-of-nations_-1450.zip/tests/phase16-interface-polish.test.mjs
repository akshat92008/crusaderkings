import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

import {buildHistoricalWorld, expandHistoricalWorld, densifyHistoricalWorld} from '../src/historical-world.js';
import {createGame, empireStats} from '../src/simulation.js';
import {resolvePoolKey, allocateCharacterName} from '../src/name-pools.js';
import {resourceModifierTooltip, successionWarningSummary} from '../src/campaign-hud.js';
import {renderDynasty} from '../src/kingdom-ui.js';

const legacyWorld = JSON.parse(fs.readFileSync(new URL('../data/world.json', import.meta.url), 'utf8'));
const historicalReference = JSON.parse(fs.readFileSync(new URL('../data/historical-polities-1450.json', import.meta.url), 'utf8'));
const world = densifyHistoricalWorld(expandHistoricalWorld(buildHistoricalWorld(legacyWorld, historicalReference)));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));

test('Cultural name pools route Asian & Middle Eastern realms to authentic cultural pools', () => {
  assert.equal(resolvePoolKey('Asia', '', '', 'ottomans'), 'Islamic & Turkic');
  assert.equal(resolvePoolKey('Asia', '', '', 'mamluks'), 'Islamic & Turkic');
  assert.equal(resolvePoolKey('Asia', '', '', 'timurids'), 'Islamic & Turkic');
  assert.equal(resolvePoolKey('Asia', '', '', 'vijayanagara'), 'Indian Subcontinent');
  assert.equal(resolvePoolKey('Asia', '', '', 'delhi'), 'Indian Subcontinent');
  assert.equal(resolvePoolKey('Asia', '', '', 'ashikaga'), 'Japanese');
  assert.equal(resolvePoolKey('Asia', '', '', 'ming'), 'Chinese & Korean');
  assert.equal(resolvePoolKey('Asia', '', '', 'joseon'), 'Chinese & Korean');
  assert.equal(resolvePoolKey('Asia', '', '', 'ayutthaya'), 'Southeast Asia');

  const game = createGame(world, 'ottomans');
  const rulerId = game.politics.realms.ottomans.ruler;
  const ruler = game.politics.people[rulerId];
  assert.ok(ruler, 'Ottoman ruler should exist');
  assert.doesNotMatch(ruler.name, /\b(Raghav|Devraj|Harsha|Taro|Kenji|Wei|Minh)\b/,
    `Ottoman ruler "${ruler.name}" should come from Islamic & Turkic pool, not mixed Asia pool`);

  const sampled = Array.from({length: 20}, (_, i) => allocateCharacterName(game, {
    realm: 'ottomans',
    continent: 'Asia',
    sex: i % 2 === 0 ? 'male' : 'female',
    seed: `pool-check:${i}`
  }));
  assert.ok(sampled.every(n => !/\b(Raghav|Devraj|Harsha|Taro|Kenji|Wei)\b/.test(n)));
});

test('Turn 1 realm.heir is synchronized so healthy realms do not show false No living heir warnings', () => {
  for (const realmId of ['ottomans', 'england', 'france', 'ming']) {
    const game = createGame(world, realmId);
    const rState = game.politics.realms[realmId];
    assert.ok(rState.heir, `${realmId} should have a synced heir id on Turn 1`);
    const warning = successionWarningSummary(game);
    assert.notEqual(warning?.label, 'No living heir', `${realmId} should not show false No living heir warning on Turn 1`);
  }

  // Explicitly clearing heir still surfaces the urgent succession warning
  const eng = createGame(world, 'england');
  eng.politics.realms.england.heir = null;
  const warn = successionWarningSummary(eng);
  assert.ok(warn && warn.level === 'urgent' && /No living heir/i.test(warn.label));
});

test('resourceModifierTooltip produces rich numerical breakdowns for all 5 topbar resources', () => {
  const game = createGame(world, 'ottomans');
  const stats = empireStats(game, 'ottomans');

  const goldTip = resourceModifierTooltip(game, stats, 'gold');
  assert.match(goldTip, /Treasury:/i);
  assert.match(goldTip, /Monthly Net:/i);
  assert.match(goldTip, /Army Upkeep:/i);

  const armyTip = resourceModifierTooltip(game, stats, 'army');
  assert.match(armyTip, /Field Armies:/i);
  assert.match(armyTip, /Upkeep:/i);

  const stabTip = resourceModifierTooltip(game, stats, 'stability');
  assert.match(stabTip, /Stability:/i);
  assert.match(stabTip, /Avg Unrest:/i);

  const presTip = resourceModifierTooltip(game, stats, 'prestige');
  assert.match(presTip, /Prestige:/i);

  const legTip = resourceModifierTooltip(game, stats, 'legitimacy');
  assert.match(legTip, /Legitimacy:/i);
});

test('renderDynasty outputs 3-generation interactive visual family tree with ruler and heir badges', () => {
  const game = createGame(world, 'ottomans');
  const html = renderDynasty(game, esc);
  assert.match(html, /class="dynasty-tree family-tree-graph"/);
  assert.match(html, /Generation II · Sovereign &amp; Consort/);
  assert.match(html, /ft-card is-ruler/);
  assert.match(html, /ft-badge ruler/);
  assert.match(html, /ft-card is-heir/);
  assert.match(html, /ft-badge heir/);
  assert.match(html, /data-character="/);
});
