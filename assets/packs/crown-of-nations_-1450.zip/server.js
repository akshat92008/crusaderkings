import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';

app.disable('x-powered-by');

app.use((req, res, next) => {
  if (req.path.endsWith('.js') || req.path.endsWith('.mjs')) {
    res.type('application/javascript; charset=utf-8');
  } else if (req.path.endsWith('.glb')) {
    res.type('model/gltf-binary');
  }
  next();
});

app.use(express.static(__dirname, {
  index: 'index.html',
  extensions: ['html'],
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));

app.get('/health', (_req, res) => {
  res.json({ ok: true, game: 'Crown of Nations 1450' });
});

app.listen(PORT, HOST, () => {
  console.log(`Crown of Nations server running at http://${HOST}:${PORT}`);
});
