// Presentation models share the authoritative campaign state.
const total=a=>(a.infantry||0)+(a.archers||0)+(a.cavalry||0),num=n=>Number.isFinite(n)?n:0;
export function characterDirectory(g,{scope='court',query='',sort='martial'}={}){const p=g.politics||{},r=g.playerCareer?.mode==='vassal'?g.playerCareer.person:p.realms?.[g.player]?.ruler,head=p.people?.[r],needle=query.trim().toLowerCase();const people=Object.values(p.people||{}).filter(c=>c.alive&&(scope==='foreign'?c.realm!==g.player:scope==='all'?true:c.realm===g.player)&&(scope!=='family'||c.house===head?.house||[head?.spouse,...(head?.children||[]),...(head?.parents||[])].includes(c.id))&&(!needle||[c.name,c.house,g.factions[c.realm]?.name,...(c.traits||[])].join(' ').toLowerCase().includes(needle)));return people.sort((a,b)=>sort==='name'?a.name.localeCompare(b.name):sort==='age'?b.age-a.age||a.name.localeCompare(b.name):num(b.skills?.[sort])-num(a.skills?.[sort])||a.name.localeCompare(b.name));}
export function vassalDirectory(g,sort='loyalty'){const p=g.politics||{},r=p.realms?.[g.player]?.ruler,groups=new Map();for(const [id,h] of Object.entries(p.holdings||{})){if(h.realm!==g.player||h.lord===r||g.provinces[id]?.owner!==g.player||!p.people[h.lord])continue;const x=groups.get(h.lord)||{id:h.lord,person:p.people[h.lord],holdings:[],wealth:0,loyalty:0,population:0,tax:0,levy:0};x.holdings.push(id);x.wealth+=num(h.wealth);x.loyalty+=num(h.loyalty);x.population+=num(g.provinces[id].population);x.tax+=num(h.tax);x.levy+=num(h.levy);groups.set(h.lord,x);}return [...groups.values()].map(x=>({...x,loyalty:x.loyalty/x.holdings.length,tax:x.tax/x.holdings.length,levy:x.levy/x.holdings.length})).sort((a,b)=>sort==='wealth'?b.wealth-a.wealth:sort==='holdings'?b.holdings.length-a.holdings.length:sort==='population'?b.population-a.population:a.loyalty-b.loyalty);}
export function armyOutliner(g){const by=new Map();for(const a of Object.values(g.armies||{})){if(a.owner!==g.player||total(a)<=0)continue;const embarked=!!g.naval?.voyages?.[a.id],key=a.province+'|'+embarked,x=by.get(key)||{province:a.province,embarked,troops:0,armies:0,unassigned:0};x.troops+=total(a);x.armies++;if(!g.military?.armies?.[a.id]?.commander)x.unassigned++;by.set(key,x);}return [...by.values()].sort((a,b)=>b.troops-a.troops||a.province.localeCompare(b.province));}
export function battleComparison(groups){const sides={attacker:{troops:0,morale:0,power:0,mix:{infantry:0,archers:0,cavalry:0}},defender:{troops:0,morale:0,power:0,mix:{infantry:0,archers:0,cavalry:0}}};for(const g of groups){const s=sides[g.side],n=Math.max(0,num(g.troopCount));if(!s||!n)continue;s.troops+=n;s.morale+=n*num(g.morale);s.power+=n*num(g.readiness?.power??1);s.mix[g.type]=(s.mix[g.type]||0)+n;}for(const s of Object.values(sides)){s.morale=s.troops?s.morale/s.troops:0;s.power=s.troops?s.power/s.troops:0;}const {attacker:a,defender:b}=sides;return {...sides,ratio:b.troops?a.troops/b.troops:null};}
export function portraitMark(person){let h=2166136261;for(const c of String(person?.id||'unknown'))h=Math.imul(h^c.charCodeAt(0),16777619);const colors=['#8d6b46','#536f76','#795d70','#6c7954','#a06e58','#6a647f'];return {color:colors[(h>>>0)%colors.length],initials:String(person?.name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(s=>s[0].toUpperCase()).join('')};}

export function pickArmyMarker(markers,x,y){let best=null,d=Infinity;for(const m of markers){if(x<m.x-m.halfWidth||x>m.x+m.halfWidth||y<m.y-14||y>m.y+m.bottom)continue;const next=Math.hypot(x-m.x,y-m.y);if(next<d){best=m;d=next;}}return best;}

export function successionWarningSummary(g){
 const r=g?.politics?.realms?.[g.player];if(!r)return null;
 const people=g.politics?.people||{},ruler=people[r.ruler],heir=r.heir?people[r.heir]:null;
 if(!heir||!heir.alive)return {level:'urgent',label:'No living heir',detail:'No surviving dynastic successor is designated. Arrange a marriage or reform succession.'};
 const regent=g.regency?.realms?.[g.player];
 if((ruler?.age??20)<18||regent?.active)return {level:'attention',label:'Regency active',detail:'A regency governs until the sovereign comes of age or reasserts authority.'};
 const claimants=Object.values(g.feudal?.claimants||{}).filter(c=>c.realm===g.player&&c.person!==r.ruler&&people[c.person]?.alive);
 if(r.successionCrisis||g.succession?.crises?.[g.player]||claimants.length>=2)return {level:'attention',label:'Claimant pressure',detail:claimants.length+' rival claimant(s) hold claims on the crown.'};
 return null;
}

export function preWarComparison(g,world,targetRealm){
 if(!g||!targetRealm||!g.factions?.[targetRealm])return null;
 const countRealmTroops=id=>Object.values(g.armies||{}).filter(a=>a.owner===id&&!g.naval?.voyages?.[a.id]).reduce((n,a)=>n+total(a),0);
 const alliesOf=id=>{
  const set=new Set();
  const treaties=g.factions?.[id]?.treaties||{};
  for(const [k,v] of Object.entries(treaties))if(v==='alliance'&&g.factions[k])set.add(k);
  for(const p of Object.values(g.diplomacy?.guarantees||{}))if(p.protected===id&&g.factions[p.guarantor])set.add(p.guarantor);
  for(const pact of Object.values(g.strategy?.pacts||{}))if(pact.expires>g.turn&&pact.members?.includes(id))for(const m of pact.members)if(m!==id)set.add(m);
  set.delete(g.player);if(id!==targetRealm)set.delete(targetRealm);else set.delete(g.player);
  return [...set].filter(x=>Object.values(g.provinces||{}).some(p=>p.owner===x));
 };
 const ourAllies=alliesOf(g.player).filter(x=>x!==targetRealm),theirAllies=alliesOf(targetRealm).filter(x=>x!==g.player);
 const ourTroops=countRealmTroops(g.player),theirTroops=countRealmTroops(targetRealm);
 const ourAllyTroops=ourAllies.reduce((n,id)=>n+countRealmTroops(id),0),theirAllyTroops=theirAllies.reduce((n,id)=>n+countRealmTroops(id),0);
 const ourTotal=ourTroops+ourAllyTroops,theirTotal=theirTroops+theirAllyTroops;
 const ratio=theirTotal?ourTotal/theirTotal:null;
 const truceUntil=g.conflict?.truces?.[g.player+':'+targetRealm]||g.conflict?.truces?.[targetRealm+':'+g.player]||0;
 return {
  target:targetRealm,ourTroops,ourAllyTroops,ourTotal,ourAllies,
  theirTroops,theirAllyTroops,theirTotal,theirAllies,
  ratio,truceMonths:Math.max(0,truceUntil-g.turn),
  verdict:ratio===null?'Unopposed':ratio>=1.8?'Strongly favored':ratio>=1.15?'Favored':ratio>=0.85?'Even':'Outnumbered'
 };
}

export function tooltipData(g,world,kind,id){
 if(!g)return '';
 if(kind==='province'){
  const p=world?.provinces?.find(x=>x.id===id),st=g.provinces?.[id];
  if(!p||!st)return '';
  const owner=g.factions?.[st.owner]?.name||'Independent';
  const culture=g.civic?.provinces?.[id]?.culture||p.culture||'Local';
  const faith=g.civic?.provinces?.[id]?.faith||p.faith||'Local';
  return p.name+' · '+owner+' · Pop '+Math.round(st.population)+'k · Dev '+st.development+' · '+culture+' · '+faith+(p.deJureKingdom?' · De Jure '+p.deJureKingdom:'');
 }
 if(kind==='character'){
  const c=g.politics?.people?.[id];if(!c)return '';
  const s=c.skills||{};
  return c.name+' ('+c.age+'y) · '+(g.factions?.[c.realm]?.name||c.realm)+' · M '+num(s.martial)+' D '+num(s.diplomacy)+' S '+num(s.stewardship)+' I '+num(s.intrigue)+' L '+num(s.learning)+((c.traits?.length)?' · '+c.traits.slice(0,3).join(', '):'');
 }
 return '';
}
export function resourceModifierTooltip(g,stats,kind){
 if(!g||!stats)return '';
 const f=g.factions?.[g.player];if(!f)return '';
 const r=g.politics?.realms?.[g.player],people=g.politics?.people||{},ruler=r?people[r.ruler]:null,heir=r?.heir?people[r.heir]:null;
 const n=v=>Math.round(num(v)).toLocaleString('en-US');
 const signed=v=>(num(v)>=0?'+':'−')+n(Math.abs(num(v)));
 if(kind==='gold'){
  const tax=num(stats.income)-num(stats.trade||0);
  return [
   'ROYAL TREASURY · '+n(f.treasury)+' gold',
   'Tax & domain revenue: +'+n(tax)+' / mo',
   'Trade & market income: +'+n(stats.trade||0)+' / mo',
   'Army & garrison upkeep: −'+n(stats.upkeep)+' / mo',
   'Net monthly balance: '+signed(stats.balance)+' / mo',
   'Food reserve: '+n(f.food)+' ('+signed(stats.foodDelta)+' / mo)'
  ].join('\n');
 }
 if(kind==='army'){
  const own=Object.values(g.armies||{}).filter(a=>a.owner===g.player&&total(a)>0);
  const inf=own.reduce((k,a)=>k+num(a.infantry),0),arc=own.reduce((k,a)=>k+num(a.archers),0),cav=own.reduce((k,a)=>k+num(a.cavalry),0);
  const unassigned=own.filter(a=>!g.military?.armies?.[a.id]?.commander).length;
  return [
   'FIELD FORCES · '+n(stats.troops)+' soldiers across '+own.length+' army'+(own.length===1?'':' armies'),
   'Infantry: '+n(inf)+' · Ranged: '+n(arc)+' · Cavalry: '+n(cav),
   'Upkeep: −'+n(stats.upkeep)+' gold / mo',
   unassigned?'Command gap: '+unassigned+' army without a general':'All field armies have appointed commanders'
  ].join('\n');
 }
 if(kind==='stability'){
  const provs=Object.values(g.provinces||{}).filter(p=>p.owner===g.player);
  const avgUnrest=provs.length?Math.round(provs.reduce((k,p)=>k+num(p.unrest),0)/provs.length):0;
  const highUnrest=provs.filter(p=>num(p.unrest)>=55).length;
  return [
   'REALM STABILITY · '+Math.round(num(f.stability))+'%',
   'Controlled provinces: '+provs.length,
   'Average provincial unrest: '+avgUnrest+'%',
   highUnrest?'Restless districts (55%+): '+highUnrest:'No districts near revolt threshold',
   'Policies · Tax lv '+(num(f.policies?.tax)+1)+' · Levy lv '+(num(f.policies?.levy)+1)+' · Tolerance lv '+(num(f.policies?.tolerance)+1)
  ].join('\n');
 }
 if(kind==='prestige'){
  const treaties=Object.values(f.treaties||{});
  const allies=treaties.filter(t=>t==='alliance').length,marriages=treaties.filter(t=>t==='marriage').length;
  return [
   'DYNASTIC PRESTIGE · '+n(f.prestige),
   'Ruling house: '+(ruler?.house||f.name),
   'Sovereign: '+(ruler?ruler.name+' ('+ruler.age+'y)':'—'),
   'Diplomatic standing: '+allies+' alliance'+(allies===1?'':'s')+' · '+marriages+' dynastic tie'+(marriages===1?'':'s')
  ].join('\n');
 }
 if(kind==='legitimacy'){
  return [
   'CROWN LEGITIMACY · '+Math.round(num(f.legitimacy))+'%',
   'Government: '+(f.government||'Monarchy'),
   'Succession law: '+(r?.law||'eldest'),
   'Designated heir: '+(heir&&heir.alive?heir.name+' ('+heir.age+'y)':'No living heir designated')
  ].join('\n');
 }
 return '';
}
