import {humanControlsRealm,humanControlsCharacter} from './player-career.js';
import {feudalHierarchy} from './feudal-obligations.js';
// Landed subjects are autonomous estate managers with personal treasuries, saved petitions, and agendas.
import {politicalEstates} from './realm-authority.js';
import {controller} from './campaign-war.js';

const cap=(x,a,b)=>Math.max(a,Math.min(b,x)),num=n=>Number.isFinite(n)?n:0;
const live=(g,id)=>{const p=g.politics?.people?.[id];return p?.alive?p:null;};
const free=(g,id)=>live(g,id)&&g.feudal?.prisoners?.[id]?.status!=='held';
const skills={chancellor:'diplomacy',marshal:'martial',steward:'stewardship',spymaster:'intrigue',scholar:'learning'};

export function initVassalCourts(g){return g.vassalCourts??={version:1,courts:{},petitions:{},history:[],lastTick:-1};}
export function vassalCourt(g,id){return g.vassalCourts?.courts?.[id]||null;}
export function vassalLiege(g,id){const p=live(g,id);if(!p)return null;const h=feudalHierarchy(g,p.realm);return h.byLord[id]?.liege??null;}

function note(g,r,id,message){
 const s=initVassalCourts(g);
 s.history.unshift({realm:r,person:id,turn:g.turn,message});
 s.history=s.history.slice(0,160);
 if(r===g.player){g.log.unshift({date:g.year+' · month '+(g.month+1),text:message});g.log=g.log.slice(0,45);}
}
function local(g,r,id){return Object.entries(g.politics.holdings).filter(([k,h])=>h.realm===r&&h.lord===id&&g.provinces[k]?.owner===r&&controller(g,k)===r);}
function eligible(g,p){return p&&p.age>=18&&free(g,p.id)&&p.id!==g.politics.realms[p.realm]?.ruler;}

export function pendingVassalPetitions(g,r){
 return Object.values(g.vassalCourts?.petitions||{}).filter(x=>x.realm===r&&x.status==='pending'&&eligible(g,live(g,x.person))&&local(g,r,x.person).some(([id])=>id===x.province));
}

function councilSlot(g,r,p){
 const realm=g.politics.realms[r],est=politicalEstates(g,r);
 if(Object.values(realm.council).includes(p.id))return null;
 if(Object.values(g.royalCourt?.realms?.[r]?.offices||{}).some(o=>o.person===p.id))return null;
 return Object.entries(realm.council).filter(([role,id])=>!est.byLord[id]?.powerful&&num(p.skills?.[skills[role]])>=num(g.politics.people[id]?.skills?.[skills[role]])-1).sort((a,b)=>num(p.skills?.[skills[b[0]]])-num(p.skills?.[skills[a[0]]])||a[0].localeCompare(b[0]))[0]?.[0]||null;
}

function changeLoyalty(g,r,id,amount){for(const [,h] of local(g,r,id))h.loyalty=cap(h.loyalty+amount,0,100);}

export function resolveVassalPetition(g,r,id,choice){
 const root=initVassalCourts(g),x=root.petitions[id],f=g.factions[r],p=x&&live(g,x.person),h=x&&g.politics.holdings[x.province];
 if(!x||x.realm!==r||x.status!=='pending'||!eligible(g,p)||h?.lord!==p.id||!local(g,r,p.id).some(([key])=>key===x.province)||!['accept','compromise','reject'].includes(choice))return {ok:false,msg:'Petition is no longer available.'};
 if(choice==='accept'){
  if(x.kind==='council'){
   if(!Object.values(g.politics.realms[r].council).includes(p.id)){
    const slot=councilSlot(g,r,p);
    if(!slot||f.treasury<80)return {ok:false,msg:'Requires an appropriate council position and 80 gold.'};
    f.treasury-=80;g.politics.realms[r].council[slot]=p.id;
   }
  }else if(x.kind==='tax'){h.tax=Math.max(0,h.tax-1);}
  else if(x.kind==='autonomy'){h.autonomy=Math.min(2,h.autonomy+1);}
  changeLoyalty(g,r,p.id,20);
 }else if(choice==='compromise'){
  if(f.treasury<75)return {ok:false,msg:'A settlement requires 75 gold.'};
  f.treasury-=75;h.wealth+=75;changeLoyalty(g,r,p.id,9);
 }else{
  changeLoyalty(g,r,p.id,-12);
  for(const xFaction of Object.values(g.conflict?.factions||{})){
   if(xFaction.realm===r&&['organizing','ultimatum'].includes(xFaction.status)&&xFaction.members.includes(x.province)){
    xFaction.pressure=cap(xFaction.pressure+8,0,100);
    xFaction.discontent=xFaction.pressure;
   }
  }
 }
 x.status=choice;x.ended=g.turn;
 const court=root.courts[p.id];
 if(court)court.lastPetition=g.turn;
 note(g,r,p.id,p.name+' petition: '+choice+'.');
 return {ok:true,msg:'Vassal petition '+(choice==='accept'?'accepted':choice==='reject'?'rejected':'settled')+'.'};
}

export function requestVassalPetition(g,r,id,province,kind){
 const root=initVassalCourts(g),p=live(g,id),h=g.politics.holdings[province];
 if(!eligible(g,p)||p.realm!==r||!local(g,r,id).some(([key])=>key===province)||!['tax','autonomy','council'].includes(kind))return {ok:false,msg:'Select your controlled estate and a valid petition.'};
 const court=root.courts[id]??={realm:r,agenda:'maintain estates',lastInvestment:-120,lastPetition:-120};
 if(g.turn-court.lastPetition<36||pendingVassalPetitions(g,r).some(x=>x.person===id)||pendingVassalPetitions(g,r).length>=3)return {ok:false,msg:'Petitions require 36 months between requests and an available audience.'};
 if((kind==='tax'&&h.tax<=0)||(kind==='autonomy'&&h.autonomy>=2)||(kind==='council'&&!councilSlot(g,r,p)))return {ok:false,msg:'The requested concession is unavailable.'};
 const key=id+':'+g.turn;
 root.petitions[key]={id:key,realm:r,person:id,kind,province,started:g.turn,deadline:g.turn+12,status:'pending'};
 court.lastPetition=g.turn;
 note(g,r,id,p.name+' petitioned the crown for '+kind+'.');
 return {ok:true,msg:'Petition submitted; the crown will respond.'};
}

function chooseAgenda(g,r,row,p,holdings){
 const bad=holdings.find(([,h])=>h.tax===2&&h.loyalty<55);
 if(bad)return {kind:'tax',province:bad[0]};
 const aut=holdings.find(([,h])=>h.autonomy<2&&h.loyalty<42);
 if(aut)return {kind:'autonomy',province:aut[0]};
 if(row.grievance&&row.loyalty<60&&councilSlot(g,r,p))return {kind:'council',province:holdings[0][0]};
 return null;
}

export function tickVassalCourts(g){
 const root=initVassalCourts(g);
 if(root.lastTick===g.turn)return;
 root.lastTick=g.turn;
 if(g.turn%6!==0)return;
 for(const [id,x] of Object.entries(root.petitions)){
  if(x.status!=='pending'){if(g.turn-x.ended>72)delete root.petitions[id];continue;}
  if(!pendingVassalPetitions(g,x.realm).some(q=>q.id===id)){x.status='lapsed';x.ended=g.turn;continue;}
  if(!humanControlsRealm(g,x.realm)){
   const f=g.factions[x.realm],p=live(g,x.person),est=politicalEstates(g,x.realm),row=est.byLord[p.id];
   const choice=row?.powerful||row?.loyalty<35?'accept':f.treasury>300?'compromise':'reject';
   if(!resolveVassalPetition(g,x.realm,id,choice).ok)resolveVassalPetition(g,x.realm,id,'reject');
  }else if(g.turn>=x.deadline)resolveVassalPetition(g,x.realm,id,'reject');
 }
 for(const r of Object.keys(g.politics.realms)){
  const est=politicalEstates(g,r);
  for(const row of est.rows){
   const p=live(g,row.id);
   if(!eligible(g,p))continue;
   const holdings=local(g,r,p.id);
   if(!holdings.length)continue;
   const court=root.courts[p.id]??={realm:r,agenda:'maintain estates',lastInvestment:-120,lastPetition:-120};
   court.realm=r;
   if(humanControlsCharacter(g,p.id))continue;
   const request=chooseAgenda(g,r,row,p,holdings);
   court.agenda=request?(request.kind==='council'?'seek council office':request.kind==='tax'?'reduce tax burden':'seek autonomy'):(p.traits?.includes('ambitious')?'expand influence':p.traits?.includes('greedy')?'accumulate wealth':'develop estates');
   if(request&&g.turn-court.lastPetition>=36&&!pendingVassalPetitions(g,r).some(x=>x.person===p.id)&&pendingVassalPetitions(g,r).length<3){
    const id=p.id+':'+g.turn;
    root.petitions[id]={id,realm:r,person:p.id,kind:request.kind,province:request.province,started:g.turn,deadline:g.turn+12,status:'pending'};
    court.lastPetition=g.turn;
    note(g,r,p.id,p.name+' has petitioned the crown for '+request.kind+'.');
   }
   // Autonomous vassal treasury & estate management (no crown treasury drained).
   if(!request&&g.turn-court.lastInvestment>=24){
    const invest=holdings.filter(([id,h])=>h.wealth>=180&&g.provinces[id].development<20).sort(([a],[b])=>g.provinces[a].development-g.provinces[b].development||a.localeCompare(b))[0];
    if(invest){
     const [id,h]=invest,pr=g.provinces[id];
     h.wealth-=120;pr.development++;pr.unrest=cap(pr.unrest-3,0,100);
     // Optionally upgrade local farm/market if buildings below 3 and wealthy.
     if(h.wealth>=160){
      const bKind=pr.buildings.farm<3?'farm':pr.buildings.market<3?'market':null;
      if(bKind){h.wealth-=100;pr.buildings[bKind]++;}
     }
     court.lastInvestment=g.turn;
    }else if(holdings[0]&&holdings[0][1].wealth>=140){
     holdings[0][1].wealth-=40;p.wealth=num(p.wealth)+40;
     court.lastInvestment=g.turn;
    }
   }
  }
 }
 for(const id of Object.keys(root.courts))if(!live(g,id))delete root.courts[id];
}
