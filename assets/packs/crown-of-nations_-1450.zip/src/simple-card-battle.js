// Banner Lines: deterministic, renderer-independent card battles.
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const byId=(a,b)=>String(a.id).localeCompare(String(b.id));
export const CARD_BATTLE_LIMIT=100;
export const cardRole=g=>g.specialistId==='horsebow'||g.type==='archers'?'ranged':g.type==='cavalry'?'mounted':'foot';
export function cardFormationChoices(group,choices){
 const role=cardRole(group),allowed=role==='ranged'?['volley_line','longbow_line','skirmish','ambush']:role==='mounted'?['cavalry_wedge','flank','encirclement','elephant_push','skirmish']:['shield_wall','pike_square','flank','ambush','skirmish'];
 return choices.filter(f=>allowed.includes(f.id));
}
export function cardRoleHint(g){
 const role=cardRole(g);
 return role==='ranged'?'Ranged support · strong against foot troops':role==='mounted'?'Fast flankers · strong against ranged troops':g.kind==='pikemen'||g.kind==='spearmen'||g.formationId==='pike_square'?'Anti-cavalry · holds the front':'Frontline · holds the field';
}
export function deploymentCells(home){
 const cells=[];for(const z of [14,25,36])for(let x=-54;x<=54;x+=12)cells.push({x,z:z*home});return cells;
}
export function freeDeploymentCell(groups,group,x,z,home){
 if(!Number.isFinite(x)||!Number.isFinite(z)||z*home<9||z*home>43||Math.abs(x)>64)return null;
 const occupied=groups.filter(g=>g!==group&&g.side===group.side&&!g.routed);
 return deploymentCells(home).filter(p=>occupied.every(g=>distance(p,g)>7)).sort((a,b)=>distance(a,{x,z})-distance(b,{x,z}))[0]||null;
}
export function toggleCardReserve(groups,g){
 if(!g||g.side!=='attacker'||g.routed)return false;
 if(g.reserve){g.reserve=false;return true;}
 const own=groups.filter(x=>x.side===g.side&&!x.routed);
 if(own.filter(x=>x.reserve).length>=Math.min(3,own.length-1))return false;
 g.reserve=true;return true;
}
export function releaseCardReserves(state){
 const own=state.groups.filter(g=>g.side==='attacker'&&!g.routed&&g.life>0);
 if(state.fieldTime>=12||!own.some(g=>!g.reserve))for(const g of own)if(g.reserve){g.reserve=false;g.deployFlash=.7;}
}
export function moveCard(g,p){
 g.x=p.x;g.z=p.z;g.lane=p.x<-12?0:p.x>12?2:1;
 for(const k of ['targetX','orderX','anchorX','moveX'])g[k]=p.x;
 for(const k of ['targetZ','orderZ','anchorZ','moveZ'])g[k]=p.z;
 g.homeDirection=Math.sign(p.z);g.facingX=0;g.facingZ=-g.homeDirection;g.facing=Math.atan2(0,g.facingZ);
 g.deploymentRevision=(g.deploymentRevision||0)+1;
}
export function arrangeCardArmy(groups,side,home,preset='balanced'){
 const cards=groups.filter(g=>g.side===side&&!g.routed),placed=[];
 for(const role of ['foot','mounted','ranged']){
  const set=cards.filter(g=>cardRole(g)===role).sort(byId);
  set.forEach((g,i)=>{
   const offset=(i-(set.length-1)/2)*12;
   let x=role==='mounted'?(i%2?1:-1)*(42-Math.floor(i/2)*12):offset,z=role==='foot'?14:role==='mounted'?25:36;
   if(preset==='defensive'){z=role==='foot'?25:36;x=role==='mounted'?(i%2?1:-1)*48:offset;}
   if(preset==='flanks'){x=role==='mounted'?(i%2?1:-1)*(54-Math.floor(i/2)*12):offset;z=role==='mounted'?14:z;}
   const cell=freeDeploymentCell(placed,g,clamp(x,-54,54),z*home,home);
   if(cell){moveCard(g,cell);placed.push(g);}
  });
 }return placed.length===cards.length;
}
const soldiers=g=>g.routed?0:Math.max(0,g.troopCount*clamp(g.life/100,0,1));
export function fieldActiveCount(groups,side){return Math.round(groups.filter(g=>g.side===side&&!g.reserve&&!g.routed).reduce((n,g)=>n+soldiers(g),0));}
export function cardBattleOutcome(groups,elapsed,defenseMode=false){
 const strength=side=>groups.filter(g=>g.side===side).reduce((n,g)=>n+soldiers(g),0);
 const a=strength('attacker'),b=strength('defender');
 if(a>0&&b>0&&elapsed<CARD_BATTLE_LIMIT)return null;
 const tie=Math.abs(a-b)<0.5;
 return {victory:tie?!!defenseMode:a>b,reason:tie?'deadlock':a<=0||b<=0?'field secured':'time limit',attacker:a,defender:b};
}
export function cardCounter(g,e){
 const a=cardRole(g),b=cardRole(e);
 if(a==='mounted'&&b==='ranged')return 1.35;
 if(a==='ranged'&&b==='foot')return 1.12;
 if(a==='foot'&&b==='mounted'&&(g.kind==='pikemen'||g.kind==='spearmen'||g.formationId==='pike_square'))return 1.45;
 return 1;
}
export function stepCardBattle(state,dt,terrainInfo=null){
 if(!Number.isFinite(dt)||dt<=0)return;
 state.fieldTime=(state.fieldTime||0)+dt;
 releaseCardReserves(state);
 state.effects=(state.effects||[]).filter(e=>(e.age+=dt)<e.duration);
 state.projectiles=(state.projectiles||[]).filter(p=>(p.t+=dt*2.3)<=1);
 const groups=state.groups.slice().sort(byId),live=groups.filter(g=>!g.reserve&&!g.routed&&g.life>0&&g.troopCount>0);
 const snapshot=new Map(live.map(g=>[g.id,{x:g.x,z:g.z,life:g.life}])),hits=new Map(),targetLoad=new Map();
 for(const g of groups){
  g.attackPulse=Math.max(0,(g.attackPulse||0)-dt);g.hitFlash=Math.max(0,(g.hitFlash||0)-dt);g.deployFlash=Math.max(0,(g.deployFlash||0)-dt);g.skirmishing=false;
  if(g.reserve){g.moving=false;g.status='reserve';continue;}
  if(g.routed){g.routAge=(g.routAge||0)+dt;g.moving=true;g.status='routing';g.statusFlags=['ROUT'];g.troops=0;const home=g.homeDirection||1;g.z=clamp(g.z+home*dt*5,-46,46);continue;}
  const enemies=live.filter(e=>e.side!==g.side),pos=snapshot.get(g.id);
  if(!pos||!enemies.length){g.moving=false;continue;}
  const score=e=>distance(pos,snapshot.get(e.id))+(g.lane!==e.lane?3:0)+(cardRole(g)==='mounted'&&cardRole(e)==='ranged'?-6:0)+Math.min(10,Math.max(0,(targetLoad.get(e.id)||0)/Math.max(1,soldiers(e))-1)*4);
  const best=enemies.slice().sort((a,b)=>score(a)-score(b)||byId(a,b))[0],old=enemies.find(e=>e.id===g.cardTargetId);
  const e=old&&score(old)<=score(best)+4?old:best;g.cardTargetId=e.id;targetLoad.set(e.id,(targetLoad.get(e.id)||0)+soldiers(g));
 const target=snapshot.get(e.id),dx=target.x-pos.x,dz=target.z-pos.z,d=Math.hypot(dx,dz),role=cardRole(g),form=g.formationId||'';
 const terrain=terrainInfo?.(g),enemyTerrain=terrainInfo?.(e);
 g.terrainName=terrain?.name||state.terrainType||'plains';g.height=terrain?.height||0;
 const reach=role==='ranged'?clamp(g.range||14,8,24):clamp(g.range||2.5,1.5,4),speed=clamp(g.speed||4,2.5,9)*clamp(terrain?.speed??1,.8,1.1);
 let step=Math.min(Math.max(0,d-reach*.88),speed*dt),moveDir=1;
 if(form==='skirmish'&&role==='ranged'&&cardRole(e)==='foot'&&d>0.01&&d<reach*.48){step=Math.min(reach*.48-d,speed*dt*.75);moveDir=-1;g.skirmishing=true;}
 g.moving=step>0.01;g.vx=d?moveDir*dx/d*step/dt:0;g.vz=d?moveDir*dz/d*step/dt:0;
 if(d>0.01){g.facingX=dx/d;g.facingZ=dz/d;g.facing=Math.atan2(g.facingX,g.facingZ);}
 if(g.moving){g.x=clamp(pos.x+g.vx*dt,-64,64);g.z=clamp(pos.z+g.vz*dt,-46,46);g.distanceMoved=(g.distanceMoved||0)+step;}
 // Soft friendly separation keeps regiment bodies legible without blocking attacks.
 for(const ally of live){if(ally===g||ally.side!==g.side)continue;const a=snapshot.get(ally.id);let sx=pos.x-a.x,sz=pos.z-a.z,dist=Math.hypot(sx,sz);if(dist>=4.6)continue;if(dist<.001){sx=byId(g,ally)<0?-1:1;sz=0;dist=1;}const push=Math.min(.09,dt*(4.6-dist)*.65);g.x=clamp(g.x+sx/dist*push,-64,64);g.z=clamp(g.z+sz/dist*push,-46,46);}
 g.targetX=target.x;g.targetZ=target.z;g.phase=(g.phase||0)+dt*(role==='mounted'?10:5);
 g.cooldown=Math.max(0,(g.cooldown||0)-dt);g.status=g.skirmishing?'skirmishing':g.moving?'moving':'engaging';
 g.statusFlags=[];
 if(g.skirmishing)g.statusFlags.push('SKIRMISH');
 if(form==='shield_wall'||form==='pike_square')g.statusFlags.push('BRACED');
 if((form==='cavalry_wedge'||form==='elephant_push')&&!g.chargeSpent&&(g.distanceMoved||0)>=6)g.statusFlags.push('CHARGE');
 if(form==='ambush'&&terrain?.inForestCover)g.statusFlags.push('AMBUSH');
 if(d>reach||g.cooldown>1e-8)continue;
 g.cooldown=form==='longbow_line'?.95:form==='volley_line'?1.04:role==='ranged'?1.15:.85;
 g.attackPulse=role==='ranged'?.45:.3;g.attackSerial=(g.attackSerial||0)+1;
 const quality=clamp((g.damage||10)/(g.type==='cavalry'?18:role==='ranged'?9:11),.65,1.65),protection=clamp(e.armor||1,.75,1.65);
 const rate=role==='ranged'?.038:role==='mounted'?.048:.046;
 const cover=role==='ranged'?clamp(enemyTerrain?.rangedMitigation??1,.8,1):1;
 const highGround=(terrain?.height??0)-(enemyTerrain?.height??0)>.75?(form==='longbow_line'||form==='volley_line'?1.16:1.1):1;
 const chargeReady=(form==='cavalry_wedge'||form==='elephant_push')&&!g.chargeSpent&&(g.distanceMoved||0)>=6;
 const flanking=(form==='flank'||form==='encirclement')&&((targetLoad.get(e.id)||0)>soldiers(g)*1.05||Math.abs(pos.x-target.x)>=12);
 const offMult=(chargeReady?(form==='elephant_push'?1.36:1.28):1)*(flanking?(form==='encirclement'?1.26:1.2):1)*(form==='ambush'&&terrain?.inForestCover?1.24:1)*(form==='longbow_line'&&cardRole(e)==='foot'?1.1:1)*(1+clamp(g.commanderMartial||0,0,25)*.015);
 const defForm=e.formationId||'';
 const defMult=(defForm==='shield_wall'&&role==='ranged'?.78:1)*(defForm==='ambush'&&enemyTerrain?.inForestCover?.84:1);
 const moraleMult=(chargeReady?1.45:1)*(flanking?1.3:1)*(defForm==='shield_wall'?.78:1);
 if(chargeReady)g.chargeSpent=true;
 if(flanking)g.statusFlags.push('FLANK');
 const loss=soldiers(g)*rate*quality*cardCounter(g,e)*cover*highGround*offMult*defMult/protection;
 const prev=hits.get(e)||{loss:0,morale:0};
 hits.set(e,{loss:prev.loss+loss,morale:prev.morale+loss*moraleMult});
 if(defForm==='pike_square'&&role==='mounted'){
  const selfPrev=hits.get(g)||{loss:0,morale:0};
  hits.set(g,{loss:selfPrev.loss+loss*.28,morale:selfPrev.morale+loss*.38});
 }
 if(role==='ranged')state.projectiles.push({sx:pos.x,sz:pos.z,tx:target.x,tz:target.z,t:0,kind:'arrow'});
 else state.effects.push({kind:'impact',x:target.x,z:target.z,age:0,duration:.32});
 }
 for(const [g,impact] of hits){const pct=100*impact.loss/Math.max(1,g.troopCount),mPct=100*impact.morale/Math.max(1,g.troopCount);const guard=1+clamp(g.commanderMartial||0,0,25)*.012;g.life=clamp(g.life-pct,0,100);g.morale=clamp((g.morale??75)-mPct*.55/guard,0,100);g.hitFlash=.18;}
 for(const g of live){
  if(g.life<=8||soldiers(g)<.5||(g.life<=35&&g.morale<=10)){g.routed=true;g.routAge=0;g.moving=true;g.attackPulse=0;g.status='routing';g.statusFlags=['ROUT'];g.troops=0;state.effects.push({kind:'rout',x:g.x,z:g.z,age:0,duration:.6});}
  else g.troops=Math.round(soldiers(g));
 }
 if(state.effects.length>64)state.effects.splice(0,state.effects.length-64);
 if(state.projectiles.length>128)state.projectiles.splice(0,state.projectiles.length-128);
}
