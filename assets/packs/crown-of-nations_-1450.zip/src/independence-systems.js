// Breakaway realms are actual campaign factions, not province owner placeholders.
import {controller} from './campaign-war.js';
import {syncTitles,isImprisoned} from './feudal-systems.js';
import {startingTroops,militaryDoctrine} from './military-doctrines.js';
import {allocateCharacterName,allocateCommanderName,allocateHouseName} from './name-pools.js';

const cap=(n,a,b)=>Math.max(a,Math.min(b,n)),clone=x=>JSON.parse(JSON.stringify(x)),pair=(a,b)=>[a,b].sort().join('|');

export function initIndependence(g){return g.independence??={version:1,next:1,states:{},history:[]};}

export function campaignWorld(g,world){
 return {
  ...world,
  factions:[
   ...world.factions,
   ...Object.values(g.factions).filter(f=>f.dynamic&&!f.rebel&&!world.factions.some(w=>w.id===f.id))
  ]
 };
}

export function independenceMembers(g,world,realm,ids){
 const allowed=new Set(ids.filter(id=>{
  const p=g.provinces[id],h=g.politics.holdings[id];
  return p?.owner===realm&&controller(g,id)===realm&&h?.realm===realm&&h.autonomy===2&&h.loyalty<30&&h.lord!==g.politics.realms[realm].ruler&&!isImprisoned(g,h.lord);
 }));
 const by=new Map(world.provinces.map(p=>[p.id,p])),groups=[];
 while(allowed.size){
  const start=allowed.values().next().value,q=[start];
  allowed.delete(start);
  for(let i=0;i<q.length;i++)for(const n of by.get(q[i])?.neighbors||[])if(allowed.delete(n))q.push(n);
  groups.push(q.sort());
 }
 const total=Object.values(g.provinces).filter(p=>p.owner===realm).length;
 return groups.filter(x=>x.length>=2&&x.length<total).sort((a,b)=>b.length-a.length||a[0].localeCompare(b[0]))[0]||[];
}

function person(g,realm,name,house,role){
 const id='c'+g.politics.next++;
 const p={id,realm,name,house,age:35,alive:true,sex:'male',parents:[],children:[],spouse:null,spouses:[],concubines:[],traits:['diligent','patient'],skills:{diplomacy:3,martial:3,stewardship:3,intrigue:2,learning:2},wealth:100,prestige:15,piety:5,claims:[],memories:[role],civic:{culture:g.civic.realms[realm].culture,faith:g.civic.realms[realm].faith,focus:null,xp:0,perks:[],stress:0,guardian:null,education:0,lastFocus:-60}};
 g.politics.people[id]=p;
 return p;
}

export function foundBreakaway(g,world,x){
 const s=initIndependence(g),parent=x.realm,old=g.factions[parent];
 if(x.newRealm||!old)return null;
 // Ignore rebel occupations from this faction's own civil war when evaluating breakaway provinces.
 const isHeldForBreakaway=id=>controller(g,id)===parent||(x.rebelFaction&&controller(g,id)===x.rebelFaction);
 const members=[...new Set(x.members)].filter(id=>g.provinces[id]?.owner===parent&&isHeldForBreakaway(id)&&g.politics.holdings[id]?.realm===parent);
 const remain=Object.values(g.provinces).filter(p=>p.owner===parent&&!members.includes(p.id));
 if(members.length<2||!remain.length)return null;
 const memberSet=new Set(members),map=new Map(world.provinces.map(p=>[p.id,p])),seen=new Set([members[0]]),queue=[members[0]];
 for(let i=0;i<queue.length;i++)for(const n of map.get(queue[i])?.neighbors||[])if(memberSet.has(n)&&!seen.has(n)){seen.add(n);queue.push(n);}
 if(seen.size!==members.length)return null;
 const candidates=[...new Set(members.map(id=>g.politics.holdings[id].lord))].map(id=>g.politics.people[id]).filter(p=>p?.alive&&p.age>=18&&!isImprisoned(g,p.id)&&p.id!==g.politics.realms[parent].ruler&&!remain.some(v=>g.politics.holdings[v.id]?.lord===p.id)).sort((a,b)=>b.skills.diplomacy+b.skills.martial-a.skills.diplomacy-a.skills.martial||a.id.localeCompare(b.id));
 if(!candidates.length)return null;
 const leader=candidates[0],capital=map.get(members[0]),id='breakaway-'+s.next++,name=(capital.name||capital.id).replace(/ Province \d+$/,'')+' Free Realm '+(s.next-1);
 const gold=Math.min(Math.max(0,old.treasury),Math.max(0,Math.round(old.treasury*members.length/(members.length+remain.length)*.5)));
 const food=Math.max(0,Math.round(old.food*members.length/(members.length+remain.length)*.5));
 old.treasury-=gold;old.food-=food;old.legitimacy=cap(old.legitimacy-10,0,100);
 g.factions[id]={...clone(old),id,name,capital:[...capital.centroid],color:['#9c739f','#3c8e95','#b68a4e','#7489b4','#b06a70'][(s.next-2)%5],dynamic:true,rebel:false,origin:parent,treasury:gold,food,prestige:20,legitimacy:60,stability:55,relations:{[parent]:-70},treaties:{},policies:{tax:1,levy:1,tolerance:1}};
 old.relations[id]=-70;g.conflict.truces[pair(parent,id)]=g.turn+36;
 g.civic.realms[id]={...clone(g.civic.realms[parent]),lastDecision:{},charterUntil:0,lastElection:g.turn,lastRuler:leader.id,cohesion:60,authority:45};
 g.politics.realms[id]={ruler:leader.id,law:g.politics.realms[parent].law,genderLaw:g.politics.realms[parent].genderLaw,faithLaw:g.politics.realms[parent].faithLaw,council:{},lastLaw:g.turn,regent:null};
 const moved=new Set(candidates.map(p=>p.id));
 for(const p of Object.values(g.politics.people))if(p.realm===parent&&p.alive&&candidates.some(c=>c.house===p.house)&&p.id!==g.politics.realms[parent].ruler&&!remain.some(v=>g.politics.holdings[v.id]?.lord===p.id))moved.add(p.id);
 for(const cid of moved)g.politics.people[cid].realm=id;
 for(const [role,cid] of Object.entries(g.politics.realms[parent].council))if(moved.has(cid))g.politics.realms[parent].council[role]=person(g,parent,allocateCharacterName(g,{realm:parent,continent:old.continent,culture:old.culture,faith:old.religion,seed:`rebel-council:${parent}:${role}:${g.turn}`}),allocateHouseName(g,{realm:parent,continent:old.continent,seed:`rch:${parent}:${role}:${g.turn}`}),role).id;
 for(const role of ['chancellor','marshal','steward','spymaster','scholar'])g.politics.realms[id].council[role]=person(g,id,allocateCharacterName(g,{realm:id,continent:old.continent,culture:old.culture,faith:old.religion,seed:`brk-council:${id}:${role}:${g.turn}`}),allocateHouseName(g,{realm:id,continent:old.continent,seed:`bch:${id}:${role}:${g.turn}`}),role).id;
 for(const p of members){
  g.provinces[p].owner=id;g.provinces[p].unrest=cap(g.provinces[p].unrest-20,0,100);
  const h=g.politics.holdings[p];h.realm=id;h.loyalty=70;
  if(!moved.has(h.lord))h.lord=person(g,id,allocateCharacterName(g,{realm:id,continent:old.continent,culture:old.culture,faith:old.religion,place:map.get(p)?.name||name,withSeat:true,seed:`brklord:${p}:${g.turn}`}),allocateHouseName(g,{realm:id,continent:old.continent,seed:`brkhouse:${p}:${g.turn}`}),'local lord').id;
  delete g.politics.situations['grievance:'+p];
 }
 const children=leader.children.map(i=>g.politics.people[i]).filter(p=>p?.alive&&p.realm===id).sort((a,b)=>b.age-a.age),heir=children[0];
 g.kingdom.courts[id]={dynasty:leader.house,ruler:{name:leader.name,age:leader.age,...leader.skills},heir:heir?{name:heir.name,age:heir.age}:{name:'No eligible child',age:0},steward:3,marshal:3,lastAudience:-12,lastChronicle:-12,lastSuccession:-12,successions:0};
 g.heritage.realms[id]={last:{},completed:0,lastCoronation:null,celebrated:[],equipped:{},seenRuler:leader.id};
 g.heritage.dynasties[id+'|'+leader.house]={realm:id,house:leader.house,renown:0,legacies:[],achievements:[]};
 g.economy.realms[id]={inflation:g.economy.realms[parent].inflation,credit:50,tariff:1,lastDebase:-120,lastRelief:-120,tradeNet:0,lastPolicy:-24,merchantGuild:false};
 g.chronicles.realms[id]={ruler:leader.id,decisionAt:-120,chain:null,lastChain:{},ambition:null,completed:[],successionAt:null};
 g.identity.realms[id]={...clone(g.identity.realms[parent]),research:null,lastTradition:g.turn,lastFaith:g.turn,faithAuthority:45};
 for(const a of Object.values(g.armies))if(a.owner===parent&&memberSet.has(a.province)&&!g.naval.voyages[a.id]){const target=remain.find(p=>controller(g,p.id)===parent);if(target)a.province=target.id;else delete g.armies[a.id];}
 const count=Math.max(20,Math.min(350,Math.round(x.rebels??x.power??members.length*45))),aid='a'+g.nextId++;
 g.armies[aid]={id:aid,owner:id,province:members[0],...startingTroops(g.factions[id],count),experience:.1,morale:75,commander:allocateCommanderName(g,id,members[0]),doctrine:militaryDoctrine(g.factions[id]).id};
 s.states[id]={id,parent,founder:leader.id,turn:g.turn,members:[...members],reason:x.status};
 x.newRealm=id;
 s.history.unshift({id,parent,turn:g.turn,provinces:[...members]});
 s.history=s.history.slice(0,100);
 syncTitles(g);
 g.log.unshift({date:g.year+' · month '+(g.month+1),text:name+' gained independence from '+old.name+'.'});
 g.log=g.log.slice(0,45);
 return id;
}
